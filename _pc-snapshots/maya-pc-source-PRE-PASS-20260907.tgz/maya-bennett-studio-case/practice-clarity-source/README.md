# Maya Bennett — Practice Clarity Blueprint (source)
Alexander Watson Studio · condensed portfolio edition · 13 pages · 1440 × 810pt

Built to **Practice Clarity — presentation standard** (established by Sofia Marin).
Format, dressing and furniture are the Studio's and do not vary; the accent colour and
everything the document says are Maya's.

## Building

    python3 build.py             render blueprint.html -> the PDF, then verify
    python3 build.py --verify    verify the existing PDF without re-rendering
    python3 checklayout.py       measure every page for overflow before rendering

`build.py` fails the build if any of the following is true:

- the page size is not 1440 × 810pt, or the page count is not 13
- Newsreader or Instrument Sans is missing, or any font is not embedded
- a retired typeface is named or embedded (Instrument Serif, Aileron, Lora, Source Sans)
- the fictional disclosure appears fewer than twice
- evidence and inference are not both labelled on several pages
- a professional body is named, or a registration/membership number appears anywhere
- the credentials disclaimer is missing

`checklayout.py` reports, per page, any element crossing the 96pt bottom margin or the
right margin, and any page whose title block crowds its content. Both must pass.

## Files

    blueprint.html     one <section class="page"> per page, 13 in order
    blueprint.css      dressing, furniture, type scale — and the single --accent value
    build.py           render + verify
    checklayout.py     overflow measurement
    assets/
      wordmark-*.svg   Studio wordmark, as supplied artwork — never re-set in a typeface
      fonts/*.woff2    Newsreader + Instrument Sans static cuts, SIL OFL, embeddable
      fonts/*-LICENSE.txt

The fonts and wordmarks are copies of the masters in
`Alexander Watson Studio/Brand and Document System/_source/brand-guidelines/assets`.
If those change, re-copy rather than editing here.

## The one variable

`--accent: #EF7F4B` — apricot, the signal colour of Maya's website. It appears only on
the rule under the running head, the pull-quote bar, and the circle of Maya's mark.
Nothing else in the dressing changes per case, and Sofia's plum does not appear.

## Discipline this document is held to

Every row of the strategic translation table names something that can be pointed at on
the live site. Where the site was found not to do the thing, the **site** was changed
and the change recorded in the concept's `readme.md` — the table was never written to
describe a better website than the one that exists.
