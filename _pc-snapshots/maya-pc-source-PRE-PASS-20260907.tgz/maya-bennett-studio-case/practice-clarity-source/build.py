#!/usr/bin/env python3
"""Render blueprint.html to a 1440 x 810pt PDF and verify it.

  python3 build.py            render and verify
  python3 build.py --verify   verify the existing PDF only
"""
import os, re, sys, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(HERE, "blueprint.html")
OUT  = os.path.join(HERE, "Maya Bennett — Practice Clarity Blueprint.pdf")
EXPECTED_PAGES = 13
RETIRED = ["Instrument Serif", "Aileron", "Lora", "Source Sans"]

def render():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.goto("file://" + SRC, wait_until="networkidle")
        pg.evaluate("document.fonts.ready")
        pg.wait_for_timeout(900)
        pg.pdf(path=OUT, prefer_css_page_size=True, print_background=True)
        b.close()

def verify():
    ok = True
    data = open(OUT, "rb").read()
    boxes = set(re.findall(rb"/MediaBox\s*\[([^\]]+)\]", data))
    pages = len(re.findall(rb"/Type\s*/Page[^s]", data))
    txt = subprocess.run(["pdftotext", OUT, "-"], capture_output=True).stdout.decode("utf8", "ignore")
    fonts = subprocess.run(["pdffonts", OUT], capture_output=True).stdout.decode("utf8", "ignore")

    def check(cond, msg):
        nonlocal ok
        print(("  ok   " if cond else "  FAIL ") + msg)
        if not cond: ok = False

    print("Verifying", os.path.basename(OUT))
    check(all(b.strip() == b"0 0 1440 810" for b in boxes), f"page size 1440x810pt  ({sorted(b.decode() for b in boxes)})")
    check(pages == EXPECTED_PAGES, f"page count is {EXPECTED_PAGES}  (found {pages})")
    check("Newsreader" in fonts, "Newsreader embedded")
    check("InstrumentSans" in fonts.replace(" ", "") or "Instrument" in fonts, "Instrument Sans embedded")
    emb = [l for l in fonts.splitlines()[2:] if l.strip()]
    check(all(re.split(r"\s{2,}", l.strip())[3:4] in ([], ["yes"]) or " yes " in l for l in emb),
          "every font embedded (no reader substitution)")
    for r in RETIRED:
        check(r not in txt and r.replace(" ", "") not in fonts, f"retired typeface absent: {r}")
    check("fictional" in txt.lower(), "fictional disclosure present in the text layer")
    check(txt.lower().count("fictional") >= 2, "fictional status stated at least twice")
    # letter-spaced small caps extract with spaces between glyphs; compare de-spaced
    squash = re.sub(r"[\s\u00a0]+", "", txt).lower()
    check("evidence" in squash and "inference" in squash, "evidence / inference separation stated")
    check(squash.count("evidence") >= 3 and squash.count("inference") >= 4,
          "evidence and inference labelled on multiple pages")
    # No named professional body, and no registration/membership number anywhere.
    for bad in ["BACP", "MBACP", "UKCP", "NCPS", "BPS", "HCPC", "COSCA", "IACP"]:
        check(not re.search(r"\b" + bad + r"\b", txt), f"no named professional body: {bad}")
    check(not re.search(r"(registration|registered|member(?:ship)?|reg\.?)\s*(no\.?|number|#)?\s*[:\-]?\s*\d",
                        txt, re.I), "no registration or membership number")
    # Where credentials are mentioned at all, it is to say none are claimed.
    flat = re.sub(r"\s+", " ", txt)
    check("registration number, supervisor or insurer is claimed" in flat,
          "credentials explicitly disclaimed")
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1

if __name__ == "__main__":
    if "--verify" not in sys.argv:
        render()
        print("rendered ->", OUT)
    sys.exit(verify())
