#!/usr/bin/env python3
"""Measure every page: does any content cross the bottom margin, or collide
with the folio or the title block? Reports in pt."""
import os, json
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
JS = r"""
()=>{
  const PT = 96/72;                       // 1pt in CSS px at 96dpi
  const pages=[...document.querySelectorAll('.page')];
  return pages.map((pg,i)=>{
    const pr=pg.getBoundingClientRect();
    const SAFE_BOTTOM = pr.top + (714*PT);   // 810 - 96 margin
    const SAFE_RIGHT  = pr.left + (1344*PT);
    let worstB=0, whoB='', worstR=0, whoR='';
    const skip=new Set(['folio','accent-rule','rule-x','rh','wordmark']);
    for(const el of pg.querySelectorAll('*')){
      if([...el.classList].some(c=>skip.has(c))||el.closest('.wordmark')) continue;
      if(!el.textContent.trim() && el.tagName!=='IMG' && el.tagName!=='SVG') continue;
      const r=el.getBoundingClientRect();
      if(r.height<1) continue;
      const ob=(r.bottom-SAFE_BOTTOM)/PT;
      if(ob>worstB){worstB=ob; whoB=el.tagName+'.'+(el.className||'').toString().slice(0,28)+' :: '+el.textContent.trim().slice(0,40);}
      const orr=(r.right-SAFE_RIGHT)/PT;
      if(orr>worstR){worstR=orr; whoR=el.tagName+'.'+(el.className||'').toString().slice(0,28);}
    }
    // title block vs content gap
    const tb=pg.querySelector('.title-block'), ct=pg.querySelector('.content');
    let gap=null;
    if(tb&&ct) gap=(ct.getBoundingClientRect().top - tb.getBoundingClientRect().bottom)/PT;
    return {page:i+1, overflowBottom:Math.round(worstB*10)/10, whoB, overflowRight:Math.round(worstR*10)/10, whoR, titleGap: gap===null?null:Math.round(gap*10)/10};
  });
}
"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":1960,"height":1200})
    pg.goto("file://"+os.path.join(HERE,"blueprint.html"), wait_until="networkidle")
    pg.wait_for_timeout(900)
    bad=0
    for r in pg.evaluate(JS):
        flag=""
        if r["overflowBottom"]>0: flag+=" BOTTOM+%.1fpt %s"%(r["overflowBottom"], r["whoB"]); bad+=1
        if r["overflowRight"]>0: flag+=" RIGHT+%.1fpt %s"%(r["overflowRight"], r["whoR"]); bad+=1
        if r["titleGap"] is not None and r["titleGap"]<14: flag+=" TIGHT-TITLE gap=%.1fpt"%r["titleGap"]; bad+=1
        print(("p%02d "%r["page"]) + (flag if flag else "ok"))
    b.close()
    print("PASS" if bad==0 else f"{bad} problem(s)")
