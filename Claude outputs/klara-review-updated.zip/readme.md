# Reading the River — website review (klara.alexanderwatson.co.uk)

Updated September 2026: added section 06 (About page linked and redesigned) and section 09 (keeping this site or starting again, with the £495 founding service). Sections are now 01–09; `nav.js` NUMBERED is 9 (it supports up to 9).

Private client diagnostic for Dr Klara Laird. Static HTML/CSS/JS, no build step, no dependencies.

## Files
- `index.html` — the review (single page)
- `assets/css/styles.css` — studio palette, Newsreader + Instrument Sans
- `assets/js/main.js` — screenshot enlargement (page works without it)
- `assets/js/nav.js` — report section bar
- `assets/js/pricing-config.js` — **the hourly rate (the only place it is set)**; `assets/js/pricing.js` renders the costs in sections 08 and 09 from estimated hours × rate, and `data-equiv` shows how many hours at the rate a fixed sum (the £495 service) equals. Set `hourlyRate: null` to show a "rate to confirm" placeholder.
- `assets/fonts/` — self-hosted woff2 + OFL licences
- `assets/img/` — cropped, redacted, optimised screenshots (WebP)
- `netlify.toml` — noindex / security headers
- `robots.txt` — deliberately allows crawling so crawlers can see the noindex

## Deploy (Netlify, manual)
1. Netlify → Add new site → Deploy manually → drag this folder (unzipped) in.
2. Site configuration → Domain management → Add a domain → `klara.alexanderwatson.co.uk`.
3. DNS, wherever alexanderwatson.co.uk's DNS is managed:
   - If Netlify DNS: Netlify adds the record itself.
   - Otherwise: add `CNAME  klara  →  <your-new-site-name>.netlify.app`.
4. Wait for Netlify to issue the HTTPS certificate (usually minutes).
5. Check: `curl -I https://klara.alexanderwatson.co.uk` shows `x-robots-tag: noindex, nofollow, …`.
6. Optional: uncomment the redirect at the bottom of `netlify.toml` (with the real site name) so the `.netlify.app` address forwards to the subdomain, then redeploy.

Not linked from alexanderwatson.co.uk and not in any sitemap. noindex stops search engines listing it; it does not make it secret. Anyone with the link can read it. Netlify's password protection needs a paid plan.
