/* Renders estimated costs from pricing-config.js.
 * Markup: <span data-cost="0.5-1"></span> (hours, min-max), <span data-rate></span>
 * and <span data-equiv="495"></span> (hours of work a fixed sum is equivalent to).
 * Without JavaScript the fallback text already in each element stays in place.
 */
(function () {
  var cfg = window.REVIEW_PRICING || {};
  var rate = typeof cfg.hourlyRate === "number" && cfg.hourlyRate > 0 ? cfg.hourlyRate : null;
  var cur = cfg.currency || "£";

  function money(n) {
    var r = Math.round(n * 100) / 100;
    return cur + (r % 1 === 0 ? String(r) : r.toFixed(2));
  }

  Array.prototype.forEach.call(document.querySelectorAll("[data-rate]"), function (el) {
    el.textContent = rate ? money(rate) + " an hour" : cur + "[rate to confirm] an hour";
    if (!rate) el.classList.add("is-placeholder");
  });

  Array.prototype.forEach.call(document.querySelectorAll("[data-cost]"), function (el) {
    var parts = el.getAttribute("data-cost").split("-").map(parseFloat);
    if (!rate) { el.textContent = cur + "[rate to confirm]"; el.classList.add("is-placeholder"); return; }
    var lo = parts[0] * rate, hi = (parts.length > 1 ? parts[1] : parts[0]) * rate;
    el.textContent = lo === hi ? money(lo) : money(lo) + "–" + money(hi);
  });

  // <span data-equiv="495"></span> → how many hours of the hourly rate that sum buys.
  Array.prototype.forEach.call(document.querySelectorAll("[data-equiv]"), function (el) {
    if (!rate) { el.textContent = "[rate to confirm] hours"; el.classList.add("is-placeholder"); return; }
    var h = parseFloat(el.getAttribute("data-equiv")) / rate;
    var whole = Math.round(h * 2) / 2;
    el.textContent = (Math.abs(h - whole) < 0.01 ? "" : "about ") + String(whole).replace(".5", "½") + " hours";
  });
})();
