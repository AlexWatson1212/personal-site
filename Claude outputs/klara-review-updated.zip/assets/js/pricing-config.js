/* Pricing for the "How I can help" section.
 *
 * This is the ONLY place the rate is set. Every cost on the page is
 * calculated from it (estimated hours × hourly rate).
 *
 * hourlyRate: your hourly rate in pounds, e.g. 55.
 *   Set to null to show a visible "rate to confirm" placeholder instead of prices.
 */
window.REVIEW_PRICING = {
  hourlyRate: 55,
  currency: "£"
};
