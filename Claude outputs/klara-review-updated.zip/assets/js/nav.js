// Persistent section bar: appears once the reader is past "In this review",
// shows where they are ("03 of 07") and offers a quiet jump menu.
// Without JavaScript the bar stays hidden and the contents list still works.
(function () {
  var bar = document.getElementById('sectionbar');
  var contents = document.getElementById('contents');
  if (!bar || !contents) return;

  var toggle = bar.querySelector('.sectionbar-toggle');
  var menu = document.getElementById('sectionbar-menu');
  var posEl = bar.querySelector('[data-pos]');
  var curEl = bar.querySelector('[data-cur]');
  var links = Array.prototype.slice.call(menu.querySelectorAll('a'));

  var items = links.map(function (a) {
    var id = a.getAttribute('href').slice(1);
    var sec = document.getElementById(id);
    return { id: id, el: sec && (sec.querySelector('h2') || sec), link: a, title: a.textContent.replace(/^\s*(\d\d|—|·)\s*/, '').trim() };
  }).filter(function (it) { return it.el; });
  var NUMBERED = 9;

  function openMenu() {
    menu.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
  }
  function closeMenu(returnFocus) {
    if (menu.hidden) return;
    menu.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
    if (returnFocus) toggle.focus();
  }

  toggle.addEventListener('click', function () {
    if (menu.hidden) openMenu(); else closeMenu(false);
  });
  links.forEach(function (a) { a.addEventListener('click', function () { closeMenu(false); }); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !menu.hidden) { e.preventDefault(); closeMenu(true); }
  });
  document.addEventListener('click', function (e) {
    if (!menu.hidden && !bar.contains(e.target)) closeMenu(false);
  });
  bar.addEventListener('focusout', function (e) {
    if (!menu.hidden && e.relatedTarget && !bar.contains(e.relatedTarget)) closeMenu(false);
  });

  var current = -1;
  function update() {
    ticking = false;
    var show = contents.getBoundingClientRect().bottom < 0;
    if (bar.hidden === show) {
      bar.hidden = !show;
      if (!show) closeMenu(false);
    }
    // Current section = the last one whose heading has reached the upper third of the screen.
    var line = Math.max(bar.offsetHeight + 60, window.innerHeight * 0.35);
    var idx = 0;
    for (var i = 0; i < items.length; i++) {
      if (items[i].el.getBoundingClientRect().top <= line) idx = i;
    }
    // At the very bottom, treat the closing section as current.
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 2) idx = items.length - 1;
    if (idx === current) return;
    current = idx;
    var it = items[idx];
    posEl.textContent = idx < NUMBERED ? ('0' + (idx + 1)) + ' of 0' + NUMBERED : 'Closing';
    curEl.textContent = it.title;
    links.forEach(function (a) { a.removeAttribute('aria-current'); });
    it.link.setAttribute('aria-current', 'true');
  }

  var ticking = false;
  function onScroll() {
    if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  update();
})();
