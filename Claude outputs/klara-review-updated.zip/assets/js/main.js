// Screenshot enlargement. Without JavaScript each screenshot link simply opens the image.
(function () {
  var dialog = document.getElementById('lightbox');
  if (!dialog || typeof dialog.showModal !== 'function') return;
  var img = dialog.querySelector('img');
  var cap = dialog.querySelector('p.cap');
  var closeBtn = dialog.querySelector('.lightbox-close');
  var lastTrigger = null;

  document.addEventListener('click', function (e) {
    var link = e.target.closest('a.shot');
    if (!link) return;
    e.preventDefault();
    lastTrigger = link;
    var thumb = link.querySelector('img');
    var fig = link.closest('figure');
    var caption = fig && fig.querySelector('figcaption');
    dialog.classList.remove('is-wide');
    img.style.width = '';
    img.onload = function () {
      // On small screens, show wide screenshots at a readable size and let the visitor pan.
      var vw = window.innerWidth;
      if (vw < 900 && img.naturalWidth > vw * 1.3) {
        dialog.classList.add('is-wide');
        img.style.width = Math.min(img.naturalWidth, Math.round(vw * 2.6)) + 'px';
      }
    };
    img.src = link.getAttribute('href');
    img.alt = thumb ? thumb.alt : '';
    cap.textContent = caption ? caption.textContent.trim() : '';
    dialog.showModal();
    closeBtn.focus();
  });

  function close() { dialog.close(); }
  closeBtn.addEventListener('click', close);
  dialog.addEventListener('click', function (e) {
    if (e.target === dialog || e.target.classList.contains('lightbox-inner')) close();
  });
  dialog.addEventListener('close', function () {
    img.removeAttribute('src');
    if (lastTrigger) lastTrigger.focus();
  });
})();
