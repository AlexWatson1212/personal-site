# Studio HQ — working copy

`site/` is the deployable Studio HQ (no build step: upload the folder as it is to the
existing Netlify site). `original/` is the deploy it was changed from, kept only as the
regression baseline. `tests/` never ships.

## Leads and the one follow up (26 September 2026)

Leads are **people in Marketing › People**. No separate CRM.

- A person is a **lead** once they reach *Enquiry*, *Quote sent* or *Won*, or have a quote
  recorded. The first time that happens an `enquired` date is stored, so they still count
  as a lead if later moved to *Not now* or *Closed*.
- Stages are unchanged in meaning; two were relabelled: `proposal` → **Quote sent**,
  `founding-client` → **Won**. *Closed* on a lead counts as lost.
- New person fields: `source` (Instagram, Referral, College, Email, Personal contact,
  Website, Other), `need`, `waiting` (them / me / nobody), `followedUp` (the date of the one
  follow up), `quote` (£), `quoteDate` (auto-filled when a quote is first entered). Existing
  fields are reused: `lastContact` (last meaningful interaction), `next` (next action).
- **The rule** (`autoFollowUp` / `followUpDue`): a lead that is still in play (not Won, Not now
  or Closed), marked *waiting on them*, never followed up, and quiet for
  `FOLLOW_UP_DAYS` (7) since `lastContact`, appears once on Home as "Follow up once with …",
  and in People as *Follow up due*.
- **Mark followed up** records `followedUp` and `lastContact` as today, keeps *waiting on
  them*, clears the manual follow-up date and next action. After that nothing is surfaced
  again for that lead, however long the silence. Only a manual *Follow up on* date, set
  deliberately, will bring them back.
- Manual *Follow up on* dates work exactly as before, for anyone.
- *Log contact* now asks "Who is waiting now?" (default: them).
- Evidence › **Leads and quotes**: enquiries, quotes sent and total quoted, won (and value),
  lost, not now, still open, and sources. Counts, not targets.
- The Clients › Leads rule cards now say one follow up, not two.

## Tests

    npm install          # playwright only
    npm test             # behaviour + regression (Chromium via Playwright)

- `tests/lead-followup.test.mjs` — the rule, its boundaries (7 days due, 6 not), every
  negative case, the form fields, filters, Evidence counts, card text, and older records.
- `tests/regression.test.mjs` — every route at 390 and 1280px against `original/`: only the
  intended pages may change; no console errors; no horizontal overflow.
