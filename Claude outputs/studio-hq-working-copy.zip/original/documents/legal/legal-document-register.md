# Legal Document Register

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

A printable copy of the register kept in the dashboard under Legal &
Agreements. The dashboard is the working version; this is for a file, a
solicitor, or an insurer who wants it on paper.

## The register

| Document | Service | Version | Status | Effective | Last reviewed | Review due | File location |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Master Service Agreement | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Straightforward Website Service Terms | Straightforward Website | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Guided Website Statement of Work | Guided Website | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Practice Clarity Statement of Work | Practice Clarity | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Cancellation, Refund and Early-Start Notice | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Privacy Notice | Studio-wide | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Client Content and Image Declaration | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Intellectual Property and Website Licence Terms | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Additional Work / Change Request Form | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Website Approval and Handover Form | All | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Hosting and Maintenance Terms | Hosting and care | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Data Processing Addendum | Studio-wide | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Complaints Procedure | Studio-wide | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |
| Legal Document Register | Studio-wide | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` | `[[ ]]` |

Status is one of: Draft · Under legal review · Approved · Retired.
Nothing is Approved until a person has set it so, having actually had it
reviewed.

## Versions in use by project

| Project | Document | Version accepted | Date accepted |
| --- | --- | --- | --- |
| `[[ PROJECT ]]` | `[[ DOCUMENT ]]` | `[[ VERSION ]]` | `[[ DATE ]]` |

A retired document stays on this register and stays attached to the projects
that used it. It is not offered when a new project records an agreement.
