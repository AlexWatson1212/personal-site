# Master Service Agreement

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

The umbrella terms between the studio and the client. A statement of work or a
set of service terms sits on top of this agreement and describes one particular
piece of work; where the two disagree, say here which one wins.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## 1. Structure

`[[ STATE THAT THIS AGREEMENT GOVERNS ALL WORK, THAT EACH PIECE OF WORK IS DESCRIBED IN A STATEMENT OF WORK OR SERVICE TERMS, AND WHICH DOCUMENT TAKES PRECEDENCE IF THEY CONFLICT. ]]`

## 2. How work is instructed

`[[ HOW AN ORDER IS PLACED AND ACCEPTED, AND AT WHAT POINT A CONTRACT IS FORMED. ]]`

## 3. Fees, payment and late payment

`[[ WHEN PAYMENT IS DUE, WHAT HAPPENS IF IT IS LATE, AND WHETHER WORK PAUSES. Note the statutory position on late payment where it applies. ]]`

## 4. Client responsibilities and delay

`[[ WHAT THE CLIENT MUST PROVIDE, AND WHAT HAPPENS WHEN THEY DO NOT: how long the studio holds a slot, and after how long a dormant project is paused or closed. ]]`

## 5. Confidentiality

`[[ MUTUAL CONFIDENTIALITY. Note that the studio will not hold clinical or session material of the client's own clients at any point. ]]`

## 6. Data protection

`[[ EACH PARTY'S ROLE UNDER UK GDPR, AND A REFERENCE TO THE PRIVACY NOTICE AND THE DATA PROCESSING ADDENDUM WHERE THE STUDIO PROCESSES PERSONAL DATA ON THE CLIENT'S BEHALF. ]]`

## 7. Warranties and disclaimers

`[[ WHAT IS WARRANTED AND WHAT IS NOT. Be explicit that no search-engine ranking, traffic level or commercial outcome is warranted. ]]`

## 8. Liability

`[[ LIABILITY CAP AND EXCLUSIONS. A solicitor must check this clause: consumer law limits what can be excluded, and an unenforceable cap is worse than none. ]]`

## 9. Termination

`[[ HOW EITHER SIDE ENDS THE AGREEMENT, WHAT IS PAYABLE ON TERMINATION, AND WHAT THE CLIENT RECEIVES. ]]`

## 10. Third-party services

`[[ HOSTING, DOMAIN REGISTRARS, FORM PROVIDERS AND PAYMENT PROVIDERS ARE THIRD PARTIES ON THE CLIENT'S OWN TERMS. State who holds those accounts. ]]`

## 11. Publicity

`[[ WHETHER THE STUDIO MAY SHOW THE WORK AS A CASE STUDY, AND WHETHER THE CLIENT'S PERMISSION IS NEEDED FIRST. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

