# Guided Website — Statement of Work

**Draft — requires UK legal review.** This was written as an operational
starting point, not by a solicitor. No claim is made that it is legally valid,
complete or sufficient, and it is not legal advice.

---

## Retired — September 2026

**This document is for a service the studio no longer offers.**

The Guided Website was one of three packages — Straightforward Website £495,
Guided Website £995, Practice Clarity + Bespoke Website £1,995. In September 2026
those three became one: the **Therapist Website at £995, with Practice Clarity
included**.

The reasoning is recorded in the studio's open decisions. Asking a client to
judge how much strategic work their own website needs asks them to make the one
judgement they are least able to make, and the one they are paying for. So the
work of understanding a practice is now inside the price rather than a tier
above it.

**Do not issue this document to a client.** It describes a package that cannot
be bought, at a price that is not offered, with a scope that excludes work now
included.

It is kept here, and in the legal register, because a document that existed
should not silently disappear from the record — a project agreed under it keeps
it. It takes no new work.

**For a current project, use the Therapist Website Service Terms.**
