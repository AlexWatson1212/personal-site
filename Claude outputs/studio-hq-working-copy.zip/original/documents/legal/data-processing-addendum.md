# Data Processing Addendum

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

Where the studio processes personal data on the client's behalf — for example
enquiry-form submissions passing through a site the studio maintains — the
client is the controller and the studio is the processor. This addendum sets
out that relationship.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Subject matter and duration

`[[ WHAT PROCESSING, AND FOR HOW LONG. ]]`

## Nature and purpose

`[[ WHY THE PROCESSING HAPPENS — for example, operating an enquiry form and passing submissions to the client's inbox. ]]`

## Categories of data and data subjects

`[[ NAME, EMAIL, TELEPHONE AND FREE-TEXT MESSAGE FROM WEBSITE VISITORS. Say plainly that the studio does not process clinical or session records, and that the client must not route them through anything the studio maintains. ]]`

## Studio obligations

`[[ PROCESS ONLY ON DOCUMENTED INSTRUCTIONS; CONFIDENTIALITY; SECURITY MEASURES; ASSISTANCE WITH DATA-SUBJECT REQUESTS; BREACH NOTIFICATION WITHOUT UNDUE DELAY; DELETION OR RETURN AT THE END. ]]`

## Sub-processors

| Sub-processor | Purpose | Location |
| --- | --- | --- |
| `[[ NAME ]]` | `[[ PURPOSE ]]` | `[[ LOCATION ]]` |

`[[ HOW THE CLIENT IS TOLD ABOUT A CHANGE OF SUB-PROCESSOR, AND WHETHER THEY MAY OBJECT. ]]`

## International transfers

`[[ WHETHER DATA LEAVES THE UK, AND ON WHAT BASIS. ]]`

## Security measures

`[[ THE ACTUAL MEASURES IN PLACE. Do not list measures that are not in place. ]]`

## Audit

`[[ WHAT INFORMATION THE STUDIO WILL PROVIDE TO DEMONSTRATE COMPLIANCE. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

