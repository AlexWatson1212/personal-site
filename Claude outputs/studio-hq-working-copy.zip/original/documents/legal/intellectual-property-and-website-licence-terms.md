# Intellectual Property and Website Licence Terms

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

Who owns what when the work is finished, and what the client is licensed to
do with the site they have been given.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## The client's content

`[[ EVERYTHING THE CLIENT SUPPLIED REMAINS THEIRS. ]]`

## The studio's material

`[[ THE UNDERLYING TEMPLATE, LAYOUT SYSTEM, COMPONENT LIBRARY, CODE AND ANY STUDIO-CREATED ARTWORK REMAIN THE STUDIO'S. State that the same template may be adapted for other clients. ]]`

## The licence granted

`[[ A LICENCE TO USE THE DELIVERED SITE FOR THE CLIENT'S OWN PRACTICE. Say whether it is perpetual, worldwide, non-exclusive and non-transferable, and what happens on sale of the practice. ]]`

## When the licence starts

`[[ ON PAYMENT IN FULL. Say what the position is before then. ]]`

## What the licence does not permit

`[[ RESALE, REDISTRIBUTION OR LICENSING OF THE UNDERLYING TEMPLATE TO ANYONE ELSE. ]]`

## Third-party components

`[[ FONTS, ICONS, LIBRARIES AND IMAGES REMAIN UNDER THEIR OWN LICENCES. List them and where each licence is recorded. Fonts in particular: confirm the licence permits the use the site makes of them. ]]`

## Source files

`[[ WHAT THE CLIENT RECEIVES AT HANDOVER, AND WHAT THEY DO NOT. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

