# Complaints Procedure

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

How a client raises a complaint, who handles it, and what happens next.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## How to complain

`[[ THE ADDRESS A COMPLAINT SHOULD BE SENT TO, AND WHAT TO INCLUDE. ]]`

## What happens

| Stage | What happens | By when |
| --- | --- | --- |
| Acknowledgement | `[[ WHAT ]]` | `[[ WORKING DAYS ]]` |
| Investigation | `[[ WHAT ]]` | `[[ WORKING DAYS ]]` |
| Written response | `[[ WHAT ]]` | `[[ WORKING DAYS ]]` |
| Review, if the client is not satisfied | `[[ WHAT ]]` | `[[ WORKING DAYS ]]` |

## If it is still not resolved

`[[ WHAT OPTIONS THE CLIENT HAS — alternative dispute resolution, a trade body, or the courts. Only name a scheme the studio is actually a member of. ]]`

## Record keeping

`[[ WHAT IS RECORDED ABOUT A COMPLAINT AND FOR HOW LONG. ]]`

## Note on professional complaints

`[[ THIS PROCEDURE COVERS COMPLAINTS ABOUT THE STUDIO'S WORK. Complaints about a therapist's own practice go to that therapist's professional body, not to the studio. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

