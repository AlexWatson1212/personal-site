# Client Content and Image Declaration

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

The client's written confirmation that they are entitled to use everything
they supply. The studio publishes what the client provides; this is the record
that the client had the right to provide it.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Declaration

The client confirms, for every word, image, logo, video and document supplied:

1. `[[ THAT THEY OWN IT, OR HOLD A LICENCE THAT PERMITS ITS USE ON THEIR WEBSITE. ]]`
2. `[[ THAT ANY IDENTIFIABLE PERSON SHOWN HAS CONSENTED TO APPEAR. ]]`
3. `[[ THAT NO CLIENT, PATIENT OR SERVICE-USER MATERIAL IS INCLUDED, AND NOTHING SUPPLIED IDENTIFIES ONE. ]]`
4. `[[ THAT PROFESSIONAL CLAIMS — TRAINING, QUALIFICATIONS, REGISTRATION OR MEMBERSHIP — ARE ACCURATE AND CURRENT. ]]`
5. `[[ THAT ANY TESTIMONIAL IS GENUINE, GIVEN WITH PERMISSION, AND PERMITTED BY THEIR PROFESSIONAL BODY. ]]`

## Stock and licensed images

| Item | Source | Licence held | Where the licence is kept |
| --- | --- | --- | --- |
| `[[ ITEM ]]` | `[[ SOURCE ]]` | `[[ LICENCE ]]` | `[[ LOCATION ]]` |

## Indemnity

`[[ THE CLIENT INDEMNIFIES THE STUDIO AGAINST CLAIMS ARISING FROM MATERIAL THEY SUPPLIED. A solicitor must check the scope of this clause. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

