# Website Approval and Handover Form

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

The client's approval of the finished site, and the record of what was handed
over.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Approval

| Field | Value |
| --- | --- |
| Site reviewed at | `[[ ADDRESS THE CLIENT REVIEWED ]]` |
| Approved by | `[[ NAME ]]` |
| Date approved | `[[ DATE ]]` |
| How the approval was given | `[[ EMAIL / SIGNED COPY / OTHER ]]` |

`[[ STATE WHAT APPROVAL MEANS: the client has seen the site, the words and the images, and confirms the professional and factual content is accurate. ]]`

## Launch

| Field | Value |
| --- | --- |
| Live address | `[[ URL ]]` |
| Date launched | `[[ DATE ]]` |
| Checked live on | `[[ DATE ]]` |

## Custody

| Item | Who holds it | Where | Notes |
| --- | --- | --- | --- |
| Domain | `[[ HOLDER ]]` | `[[ REGISTRAR ]]` | `[[ NOTES ]]` |
| Hosting account | `[[ HOLDER ]]` | `[[ HOST ]]` | `[[ NOTES ]]` |
| Repository or source files | `[[ HOLDER ]]` | `[[ LOCATION ]]` | `[[ NOTES ]]` |
| Enquiry inbox | `[[ HOLDER ]]` | `[[ PROVIDER ]]` | `[[ NOTES ]]` |
| Analytics, if any | `[[ HOLDER ]]` | `[[ PROVIDER ]]` | `[[ NOTES ]]` |

Never write a password, key or other credential on this form. Record where
access is held, not what the access is.

## What happens after handover

`[[ WHAT SUPPORT, IF ANY, IS INCLUDED AFTER LAUNCH, FOR HOW LONG, AND WHAT IS CHARGED. Refer to the Hosting and Maintenance Terms if a care plan applies. ]]`

## Defects after launch

`[[ HOW LONG THE CLIENT HAS TO REPORT A DEFECT IN THE DELIVERED WORK, AND WHAT COUNTS AS A DEFECT RATHER THAN A CHANGE. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

