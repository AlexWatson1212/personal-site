# Practice Clarity Statement of Work

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

The scope of a Practice Clarity engagement: what is produced, what the client
contributes, and what it deliberately is not.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Project and service

| Field | Value |
| --- | --- |
| Project / service | `[[ PROJECT OR SERVICE — e.g. Straightforward Website ]]` |
| Price | `[[ PRICE, INCLUSIVE OR EXCLUSIVE OF VAT — say which ]]` |
| Payment schedule | `[[ PAYMENT SCHEDULE — e.g. paid in full at checkout before work begins; or deposit X% on order and balance before launch ]]` |
| Payment route | `[[ ONLINE CHECKOUT / SECURE PAYMENT LINK / BANK TRANSFER / INVOICE ]]` |
| Payment terms for invoices | `[[ DAYS FROM INVOICE DATE ]]` |
| Agreed start date | `[[ START DATE ]]` |
| Target delivery of first version | `[[ DATE OR WORKING DAYS FROM COMPLETE INTAKE ]]` |
| Revision allowance | `[[ NUMBER OF CONSOLIDATED ROUNDS — copy changes and website changes share these ]]` |
| Client response period | `[[ WORKING DAYS TO RETURN QUESTIONNAIRE, FEEDBACK AND APPROVAL ]]` |

## Included scope

`[[ LIST EXACTLY WHAT IS INCLUDED — number of pages, the questionnaire, one delivered version, the consolidated revision rounds, a second version, launch to the client's domain, and the handover record ]]`

## Exclusions

`[[ LIST WHAT IS NOT INCLUDED — for example: copywriting from scratch, photography, logo design, ongoing content changes, third-party plugin or subscription costs, domain and hosting fees, SEO campaigns, email hosting, printed material, anything not listed above ]]`

## Timeline

`[[ SET OUT THE TIMELINE AGAINST COMPLETE INTAKE RATHER THAN AGAINST THE ORDER DATE. State what happens if intake materials arrive late, and after how long a dormant project is treated as paused. ]]`

## Client responsibilities

`[[ WHAT THE CLIENT MUST SUPPLY AND BY WHEN — practice details, page words, images with permission to use them, logo artwork or agreement to set the name in type, colour preference, domain access, the address enquiries should reach, and their own privacy, data-retention and safeguarding wording. Say plainly that the studio does not write policy wording on the client's behalf. ]]`

## Revision allowance

`[[ STATE THE NUMBER OF ROUNDS AND THAT THEY ARE CONSOLIDATED: one list, once. Say that copy changes and website changes come out of the same allowance, and what happens to changes that arrive after a round has been closed. ]]`

## Additional work

`[[ STATE THAT ANY WORK BEYOND THE INCLUDED SCOPE OR ALLOWANCE IS QUOTED IN WRITING AND BEGINS ONLY ON WRITTEN APPROVAL. Reference the Additional Work / Change Request Form. ]]`

## Cancellation and refunds

`[[ SET OUT THE CANCELLATION POSITION, INCLUDING THE STATUTORY POSITION FOR CONSUMERS WHERE IT APPLIES, AND WHAT IS REFUNDABLE AT EACH POINT: before work begins, after intake, after the first version is delivered, and after approval. See the Cancellation, Refund and Early-Start Notice. ]]`

## Intellectual property

`[[ SET OUT WHO OWNS WHAT: the client's own content stays theirs; the underlying reusable design system and studio-created assets stay the studio's; and the client receives a licence to use the delivered site. Say when the licence takes effect — normally on payment in full. See the Intellectual Property and Website Licence Terms. ]]`

## Approval and handover

`[[ STATE WHAT APPROVAL MEANS, HOW IT IS GIVEN, AND WHAT HAPPENS AT HANDOVER: what the client receives, who holds the domain, the hosting account and the repository, and what support (if any) follows. See the Website Approval and Handover Form. ]]`

## What is produced

`[[ THE PRACTICE CLARITY BRIEF: what the practice is for, who it is for, the language it uses, and what it will not say. Describe the deliverable and its format. ]]`

## What the client contributes

`[[ THE INTAKE QUESTIONNAIRE, A CLARITY CONVERSATION, AND THE TIME TO READ AND CORRECT A DRAFT. ]]`

## Approval

`[[ APPROVAL MEANS THE CLIENT HAS READ THE BRIEF AND EITHER RECOGNISED IT OR CORRECTED IT AND APPROVED THE CORRECTION. Record the date, who approved it and how. ]]`

## What this is not

`[[ NOT THERAPY, NOT SUPERVISION, NOT CLINICAL CONSULTANCY, AND NOT A MARKETING PERSONA. It is a written account of the practice, in the practitioner's own register, accurate enough to build a website on. ]]`

## Professional boundaries

`[[ THE STUDIO DOES NOT REQUEST, RECEIVE OR HOLD CLINICAL OR SESSION MATERIAL. Any example used publicly is invented or fully anonymised with written permission. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.
