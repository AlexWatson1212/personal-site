# Hosting and Maintenance Terms

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

What a care plan covers, what it does not, and how either side ends it.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## What is included each month

`[[ LIST THE INCLUDED WORK AND ITS SIZE — for example, a stated number of small content changes, uptime checks, dependency updates, and a backup regime. Be specific: an unbounded plan becomes unpaid support. ]]`

## What is not included

`[[ NEW PAGES, REDESIGNS, NEW FEATURES, CONTENT WRITING, THIRD-PARTY SUBSCRIPTION COSTS, DOMAIN AND HOSTING FEES CHARGED BY THE PROVIDER. ]]`

## Response expectations

`[[ WHAT THE CLIENT CAN EXPECT AND BY WHEN. Distinguish a site that is down from a change request. Do not promise a response time that cannot be met by one person. ]]`

## Charges

| Field | Value |
| --- | --- |
| Monthly or annual fee | `[[ FEE ]]` |
| Billing period | `[[ PERIOD ]]` |
| Hourly rate for work outside the plan | `[[ RATE ]]` |
| Review cadence | `[[ HOW OFTEN THE PLAN IS REVIEWED ]]` |

## Ending the plan

`[[ NOTICE PERIOD ON BOTH SIDES, WHAT HAPPENS TO THE SITE, AND WHAT THE CLIENT RECEIVES ON EXIT. ]]`

## Third-party providers

`[[ HOSTING AND DOMAIN SERVICES ARE PROVIDED BY THIRD PARTIES ON THEIR OWN TERMS. State who holds the accounts and who pays the provider directly. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

