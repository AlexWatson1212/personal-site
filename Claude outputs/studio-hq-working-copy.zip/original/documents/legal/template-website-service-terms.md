# Straightforward Website Service Terms

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

The service terms for a Straightforward Website: a complete, pre-made website
design adapted to the practice through a questionnaire, delivered as a first
version, revised through up to two consolidated rounds shared across words and
visuals, approved, launched and handed over.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Project and service

| Field | Value |
| --- | --- |
| Project / service | `[[ PROJECT OR SERVICE — e.g. Straightforward Website ]]` |
| Price | `[[ PRICE, INCLUSIVE OR EXCLUSIVE OF VAT — say which ]]` |
| Payment schedule | `[[ PAYMENT SCHEDULE — e.g. paid in full at checkout before work begins; or deposit X% on order and balance before launch ]]` |
| Payment route | `[[ ONLINE CHECKOUT / SECURE PAYMENT LINK / BANK TRANSFER / INVOICE ]]` |
| Payment terms for invoices | `[[ DAYS FROM INVOICE DATE ]]` |
| Agreed start date | `[[ START DATE ]]` |
| Target delivery of first version | `[[ DATE OR WORKING DAYS FROM COMPLETE INTAKE ]]` |
| Revision allowance | `[[ NUMBER OF CONSOLIDATED ROUNDS — copy changes and website changes share these ]]` |
| Client response period | `[[ WORKING DAYS TO RETURN QUESTIONNAIRE, FEEDBACK AND APPROVAL ]]` |

## Included scope

`[[ LIST EXACTLY WHAT IS INCLUDED — number of pages, the questionnaire, a first delivered version, up to two consolidated revision rounds, the subsequent versions needed to complete those rounds, launch to the client's domain, and the handover record ]]`

## Exclusions

`[[ LIST WHAT IS NOT INCLUDED — for example: copywriting from scratch, photography, logo design, ongoing content changes, third-party plugin or subscription costs, domain and hosting fees, SEO campaigns, email hosting, printed material, anything not listed above ]]`

## Timeline

`[[ SET OUT THE TIMELINE AGAINST COMPLETE INTAKE RATHER THAN AGAINST THE ORDER DATE. State what happens if intake materials arrive late, and after how long a dormant project is treated as paused. ]]`

## Client responsibilities

`[[ WHAT THE CLIENT MUST SUPPLY AND BY WHEN — practice details, page words, images with permission to use them, logo artwork or agreement to set the name in type, colour preference, domain access, the address enquiries should reach, and their own privacy, data-retention and safeguarding wording. Say plainly that the studio does not write policy wording on the client's behalf. ]]`

## Revision allowance

`[[ STATE THE NUMBER OF ROUNDS AND THAT THEY ARE CONSOLIDATED: one list, once. Say that copy changes and website changes come out of the same allowance, and what happens to changes that arrive after a round has been closed. ]]`

## Additional work

`[[ STATE THAT ANY WORK BEYOND THE INCLUDED SCOPE OR ALLOWANCE IS QUOTED IN WRITING AND BEGINS ONLY ON WRITTEN APPROVAL. Reference the Additional Work / Change Request Form. ]]`

## Cancellation and refunds

`[[ SET OUT THE CANCELLATION POSITION, INCLUDING THE STATUTORY POSITION FOR CONSUMERS WHERE IT APPLIES, AND WHAT IS REFUNDABLE AT EACH POINT: before work begins, after intake, after the first version is delivered, and after approval. See the Cancellation, Refund and Early-Start Notice. ]]`

## Intellectual property

`[[ SET OUT WHO OWNS WHAT: the client's own content stays theirs; the underlying reusable design system and studio-created assets stay the studio's; and the client receives a licence to use the delivered site. Say when the licence takes effect — normally on payment in full. See the Intellectual Property and Website Licence Terms. ]]`

## Approval and handover

`[[ STATE WHAT APPROVAL MEANS, HOW IT IS GIVEN, AND WHAT HAPPENS AT HANDOVER: what the client receives, who holds the domain, the hosting account and the repository, and what support (if any) follows. See the Website Approval and Handover Form. ]]`

## The path

The work follows a fixed path, and each step has to happen before the next one:

1. Payment received
2. Welcome sent
3. Questionnaire sent
4. Questionnaire returned
5. Materials checked
6. Intake complete
7. Version One in progress
8. Version One delivered
9. Consolidated revisions received
10. Version Two in progress
11. Version Two delivered
12. Client approval
13. Launch preparation
14. Launched
15. Handover complete

Steps 9–11 record a consolidated revision round. Repeat them for the second
included round, if the client uses it, before final approval.

`[[ CONFIRM THAT PAYMENT DOES NOT ITSELF START THE DESIGN WORK: work begins once the questionnaire is returned, the materials are checked and intake is confirmed complete. ]]`

## What a consolidated round means

`[[ EXPLAIN THAT EACH ROUND IS GIVEN AS A SINGLE LIST. Changes that arrive separately over the response period are collected into that round. A round is closed when its revised version is delivered. The package includes up to two rounds shared across words and visuals; changes raised after the allowance is used are additional work. ]]`

## If materials do not arrive

`[[ HOW LONG THE STUDIO WAITS, WHAT HAPPENS TO THE SLOT, AND WHETHER ANY PART OF THE PRICE IS RETAINED IF THE CLIENT NEVER SUPPLIES WHAT IS NEEDED. ]]`

## What the client is responsible for publishing

`[[ THE CLIENT IS RESPONSIBLE FOR THE ACCURACY OF EVERYTHING PUBLISHED ABOUT THEIR PRACTICE — training, registration or membership wording, fees, availability, and their own privacy, data-retention and safeguarding statements. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.
