# Privacy Notice

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

What personal data the studio holds, why, for how long, and on what basis.
This notice is about the studio's own processing. Where the studio processes
personal data on a client's behalf, the Data Processing Addendum applies.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## Who we are

`[[ CONTROLLER NAME AND CONTACT DETAILS — the studio's legal name and an address for data-protection enquiries. State whether registration with the ICO is required and, if so, the registration number. ]]`

## What we collect

`[[ ENQUIRY AND CLIENT CONTACT DETAILS, PROJECT CORRESPONDENCE, PAYMENT REFERENCES (NEVER CARD DETAILS), AND THE OPERATIONAL RECORDS KEPT ABOUT A PROJECT. ]]`

## Why, and on what lawful basis

`[[ CONTRACT, LEGITIMATE INTERESTS AND LEGAL OBLIGATION — set out which applies to which category. ]]`

## How long we keep it

`[[ RETENTION PERIODS BY CATEGORY, AND THE REASON FOR EACH — for example, accounting records for the statutory period. ]]`

## Who else sees it

`[[ PROCESSORS: EMAIL, HOSTING, PAYMENTS, FILE STORAGE. Name them, and say where they process data. ]]`

## Your rights

`[[ ACCESS, RECTIFICATION, ERASURE, RESTRICTION, PORTABILITY, OBJECTION, AND THE RIGHT TO COMPLAIN TO THE ICO. Give the ICO's contact route. ]]`

## Website visitors

`[[ WHAT THE STUDIO SITE ITSELF COLLECTS: analytics, cookies, form submissions. If nothing is collected, say so plainly — it is a real answer. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

