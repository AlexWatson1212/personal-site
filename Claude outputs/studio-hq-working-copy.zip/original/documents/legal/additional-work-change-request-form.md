# Additional Work / Change Request Form

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

One form per piece of additional work. Nothing beyond the agreed scope begins
until this is quoted in writing and approved in writing.

## The request

| Field | Value |
| --- | --- |
| Reference | `[[ REFERENCE ]]` |
| Raised by | `[[ NAME ]]` |
| Date raised | `[[ DATE ]]` |
| What is being asked for | `[[ DESCRIPTION ]]` |
| Why it is outside the agreed scope | `[[ REASON — e.g. beyond the revision allowance, or not in the included scope ]]` |

## The quote

| Field | Value |
| --- | --- |
| Price | `[[ PRICE ]]` |
| What the price includes | `[[ INCLUDED ]]` |
| What it does not include | `[[ EXCLUDED ]]` |
| Effect on the timeline | `[[ REVISED DATES ]]` |
| Payment terms for this work | `[[ TERMS ]]` |
| Quote sent on | `[[ DATE ]]` |
| Quote valid until | `[[ DATE ]]` |

## Written approval

Work begins only when this section is completed.

| Field | Value |
| --- | --- |
| Approved by | `[[ NAME ]]` |
| Date approved | `[[ DATE ]]` |
| How the approval was given | `[[ EMAIL / SIGNED COPY / OTHER ]]` |

Record the same details against the project in the dashboard. A change request
recorded without the quote and the approval will not satisfy the approval gate,
which is the point of it.

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

