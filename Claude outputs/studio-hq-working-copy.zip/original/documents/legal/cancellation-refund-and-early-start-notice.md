# Cancellation, Refund and Early-Start Notice

> **Draft — requires UK legal review.**
>
> This document was written inside the Alexander Watson Studio dashboard as an
> operational starting point. It has not been drafted, checked or approved by a
> solicitor. No claim is made that it is legally valid, complete, or sufficient
> for any particular set of circumstances, and it is not legal advice. Have a
> UK solicitor review it before it is issued to a paying client, and record the
> outcome in the Legal & Agreements register.
>
> Fields in `[[ double square brackets ]]` are to be completed. Delete any
> clause that does not apply rather than leaving it in as decoration.

How cancellation and refunds work, and the express request a client makes if
they want work to begin before the cancellation period has run out.

## The studio

| Field | Value |
| --- | --- |
| Legal name | `[[ STUDIO LEGAL NAME ]]` |
| Trading name | `[[ STUDIO TRADING NAME ]]` |
| Business address | `[[ STUDIO BUSINESS ADDRESS ]]` |
| Company number (if a registered company) | `[[ COMPANY NUMBER — leave blank if a sole trader ]]` |
| VAT number (if registered) | `[[ VAT NUMBER — leave blank if not registered ]]` |
| Address for notices | `[[ CONTACT EMAIL FOR LEGAL NOTICES ]]` |

## The client

| Field | Value |
| --- | --- |
| Client legal name | `[[ CLIENT LEGAL NAME ]]` |
| Business or practice name | `[[ CLIENT BUSINESS / PRACTICE NAME ]]` |
| Business address | `[[ CLIENT BUSINESS ADDRESS ]]` |
| Contact name | `[[ CLIENT CONTACT NAME ]]` |
| Contact email | `[[ CLIENT CONTACT EMAIL ]]` |
| Company number (if applicable) | `[[ CLIENT COMPANY NUMBER — or blank ]]` |

## Statutory cancellation rights

`[[ SET OUT THE STATUTORY POSITION FOR CONSUMERS WHERE THE CONTRACT IS MADE AT A DISTANCE OR OFF-PREMISES, INCLUDING THE LENGTH OF THE CANCELLATION PERIOD AND HOW TO CANCEL. A solicitor must confirm whether the client is a consumer or a business for this purpose, and what the correct period and wording are. ]]`

## Early start — express request

If the client wants work to begin inside the cancellation period, they say so
here. This is a request the client makes; it is never assumed from the fact
that they have paid.

| Field | Value |
| --- | --- |
| I request that work begins immediately | `[[ YES / NO ]]` |
| I understand what this means for my cancellation rights | `[[ INITIALS ]]` |
| Date of request | `[[ DATE ]]` |

`[[ EXPLAIN THE EFFECT OF AN EARLY START ON THE RIGHT TO CANCEL AND ON WHAT IS PAYABLE FOR WORK ALREADY DONE. ]]`

## Refunds at each point

| Point reached | Refund position |
| --- | --- |
| Before intake begins | `[[ POSITION ]]` |
| After intake, before Version One | `[[ POSITION ]]` |
| After Version One is delivered | `[[ POSITION ]]` |
| After approval | `[[ POSITION ]]` |
| After launch | `[[ POSITION ]]` |

## If the studio cancels

`[[ WHAT HAPPENS AND WHAT IS REFUNDED IF THE STUDIO IS UNABLE TO CONTINUE. ]]`

## How a refund is made

`[[ REFUNDS ARE MADE BY THE SAME ROUTE THE PAYMENT ARRIVED BY, WITHIN A STATED PERIOD. Record refunds against the project in the dashboard as partially refunded or refunded — a refund is recorded, not quietly absorbed. ]]`

## Governing law

This agreement is governed by the law of `[[ ENGLAND AND WALES / SCOTLAND / NORTHERN IRELAND ]]` and the courts of that jurisdiction have exclusive jurisdiction.

## Signatures

| | Studio | Client |
| --- | --- | --- |
| Name | `[[ NAME ]]` | `[[ NAME ]]` |
| Position | `[[ POSITION ]]` | `[[ POSITION ]]` |
| Date | `[[ DATE ]]` | `[[ DATE ]]` |
| Signature | `[[ SIGNATURE ]]` | `[[ SIGNATURE ]]` |

---

**Version** `[[ VERSION ]]` · **Effective from** `[[ EFFECTIVE DATE ]]` · **Status: Draft — requires UK legal review**

Record this document, its version and its status in the dashboard under
Legal & Agreements. Do not describe it as approved until a solicitor has
reviewed it and you have set its status to Approved yourself.

