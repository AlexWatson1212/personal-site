# Continuity

**What this answers.** What happens to clients if Alexander becomes seriously
ill, is unavailable for a long period, or stops trading.

**Status: model agreed, person not yet named.**

---

## The honest position

The primary continuity mechanism is not a person. It is the **mandatory recorded
launch handover**: every client already holds the complete source, the built
files, their content, and instructions for deploying elsewhere — and their domain
has been in their own name throughout.

A client in that position can walk to another developer without anyone's help.

The named contact is a **backstop**, covering the narrower case: a website still
hosted on studio infrastructure, or a project mid-build, while Alexander is
unavailable.

Do not describe this as more than it is. The studio is one person, and a
continuity arrangement that implied otherwise would be a worse promise than the
true one.

---

## What is needed

**1. A named person.** *Not yet identified.* They do **not** need to be
technical. Their role is limited to:

- accessing the continuity instructions when necessary
- helping a client locate the information and assets they need to move to
  another developer

**2. Secure emergency access.** Through the studio password manager's emergency
access feature — a delayed-release mechanism the named person can trigger. Not
a copy of credentials handed over in advance.

**3. This instruction sheet**, kept where the named person can reach it.

---

## The instruction sheet

*To be completed once the person is named and the accounts exist.*

> **If Alexander is unavailable for an extended period**
>
> Every client of Alexander Watson Studio already owns their website outright
> and already holds a complete copy of it. Their domain names are registered in
> their own names and have always been under their own control.
>
> **What you may need to tell a client who contacts you:**
>
> - Their website belongs to them. There is nothing to buy back and nothing to release.
> - They were sent a complete copy at launch — source files, built files, their
>   content, and instructions. It will be in their email from the launch date.
>   If they cannot find it, it can be recovered from the studio accounts below.
> - Their domain is in their own name. They control it. It is not affected.
> - Any competent web developer can take over from the handover pack. They do
>   not need a specialist and they do not need to start again.
>
> **Where things are:** [password manager, and how to trigger emergency access]
>
> **The accounts that matter:** the studio GitHub organisation (client source),
> Netlify (live sites), the studio Google Drive (project documents).
>
> **What not to do:** do not attempt to change or repair a website. Do not share
> credentials with a client. Point them to their own handover pack and let their
> own developer work from it.

---

## Review

Check annually, and whenever an account or provider changes. An out-of-date
continuity sheet is worse than none, because it will be trusted.
