# ICO question list

**Not yet sent.** These are the data-protection questions that the ICO's advice
service for small organisations can answer authoritatively and at no cost. They
are deliberately kept out of the solicitor brief.

**Escalate to the solicitor only** where an ICO answer leaves genuine ambiguity
affecting the contract or the business risk.

**Context to give them:** UK sole trader, no employees, designing and building
websites for therapists in private practice. Holds client business information
and website material — names, contact details, professional registrations, fees,
photographs, copy. Explicitly does not hold, ask for, or want any information
about the therapists' own clients.

---

## 1. Article 28 and a free consumer account

The studio proposes to store client project materials in Google Drive.

Google's Cloud Data Processing Addendum applies to paid services — Workspace,
Cloud Identity, Google Cloud Platform — and states that it does not cover free
consumer accounts. A free consumer Google account therefore appears to come with
no Article 28 processor contract.

**Question:** for a sole-trader web-design studio storing client project
materials, is a service carrying an Article 28 data-processing agreement — such
as Google Workspace — required, rather than a free consumer Google account?

*If the answer is yes, Google Workspace Business Starter is the preferred
solution, because it would also consolidate business email and Drive and remove
the current arrangement in which mail forwards from Namecheap into a personal
Gmail account.*

## 2. Do we need to register and pay the data protection fee?

The studio has not yet registered. The ICO states that organisations including
sole traders that use personal information need to pay the fee unless exempt.

**Question:** does this business need to register, and at which tier? *The ICO
self-assessment will be completed once the business address has been purchased,
since registration requires an address and that address appears on the public
register.*

## 3. Transfer mechanisms where the provider's documentation is unclear

Five providers, with what each states:

| Provider | Role | What their documentation says |
|---|---|---|
| FreeAgent Central Ltd (UK) | Processor | DPA incorporated into the terms of service automatically. Names adequacy, EU SCCs and the UK Addendum. Sub-processors include AWS, Google, DigitalOcean and others processing in the US. |
| Namecheap, Inc. (US) | Processor — email hosting | Names EU SCCs, and states "the UK SCCs form part of this DPA… until such time that the United Kingdom adopts new Standard Contractual Clauses." The instrument is not named. |
| GitHub B.V. (NL entity, US processing) | Processor — client repositories | EU SCCs under 2021/914, plus certification to the EU-US Data Privacy Framework including the UK Extension. |
| WeTransfer B.V. (NL) | Processor — occasional file transfer | Adequacy, else EU SCCs Module Two or Three. **No UK Addendum or IDTA referenced.** |
| National Westminster Bank plc (Mettle) | Independent controller, not a processor | Adequacy, or a contract "on terms approved by the UK." |

**Questions:**

**(a)** Namecheap's DPA refers to "the UK SCCs" without naming the instrument. Is
that sufficient, and what should a small controller do where a processor's
wording is imprecise in this way?

**(b)** WeTransfer B.V. is established in the Netherlands, so a UK-to-Netherlands
transfer is covered by UK adequacy for the EEA. Their DPA references no UK
addendum. Does that create a gap the studio needs to close, given their onward
transfers are governed by their own SCCs?

**(c)** GitHub is certified under the UK Extension to the EU-US Data Privacy
Framework. The studio understands it must check GitHub has active status on the
DPF list and is registered to receive non-HR data. Is anything else required?

**(d)** Is a transfer risk assessment needed for any of these, given the volume
and the nature of the data?

## 4. Naming the bank correctly

The studio takes payment by bank transfer. Its bank holds client names and
payment details.

**Question:** is it correct to describe the bank in the privacy notice as an
independent controller under its own regulatory obligations, rather than as a
processor acting on the studio's instructions?

## 5. How much of this belongs in the privacy notice

**Question:** how much of the transfer detail above must appear in the published
privacy notice, and how much can properly sit in internal records instead?

---

## What to do with the answers

Record each one against its field in `_data/legal.yml` in the public site
repository, or as a decision here. Do not paraphrase an ICO answer into the
privacy notice — quote what the studio actually does.
