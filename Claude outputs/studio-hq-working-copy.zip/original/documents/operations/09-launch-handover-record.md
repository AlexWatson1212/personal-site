# Launch handover — mandatory, and recorded

**Handover happens at launch, as a matter of course.** Not on request, not when
a relationship ends. This is the single most important continuity decision the
studio has made, and it only works if it actually happens every time.

Once a client holds this pack, they do not need the studio — or anyone acting
for the studio — to reach their own website. That converts "Alexander is
unavailable" from a crisis into an inconvenience.

**Handover costs nothing.** Say so.

---

## The pack

One folder, sent as a single archive, with a plain README at the top.

| Item | What it is |
|---|---|
| `source/` | The complete source of the website — templates, styles, content files, and the repository history |
| `build/` | The built static files a host needs to serve, exactly as deployed |
| `content/` | Their copy, their images at original size, and the logo files they supplied or that were made for them |
| `README.md` | How to deploy the built files, how to point the domain, how to rebuild from source |
| `dependencies.md` | Every third-party service the site touches, what it costs, and whose account it is on |

**In the README, be explicit about the difference** between `build/` and
`source/`: the built files work on any host as they are, and need no developer.
The source needs one. A client who does not know that will assume they are
stranded when they are not.

---

## Record it

Not filed, not done. Record on the project:

- [ ] Date the pack was sent
- [ ] How it was sent, and where the copy is kept
- [ ] Confirmation the client received it
- [ ] Domain confirmed as in the client's own name and under their control

An unrecorded handover is indistinguishable from one that never happened, and
the whole continuity argument rests on it having happened.

---

## What to say

> Everything for your website is attached. The built version works on any host
> as it is; the source is there too if a developer ever needs it, along with
> instructions and a list of everything the site depends on.
>
> You do not need to do anything with this. It is yours, it is complete, and it
> is here so that you are never dependent on me being available. Your domain has
> been in your own name throughout.

---

## The three moments handover happens

1. **At launch**, always.
2. **Whenever the client asks**, at any point afterwards.
3. **Before a website is removed** from studio infrastructure if Website Care is
   not continued — clause 12 gives at least thirty days' notice, and the pack
   goes with the notice, not after it.
