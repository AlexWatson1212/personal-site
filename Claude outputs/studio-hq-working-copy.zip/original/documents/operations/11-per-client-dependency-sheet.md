# Per-client dependency sheet

One per client. Filled at launch, goes into the handover pack as
`dependencies.md`, and kept on the project.

**Records where things are and who holds them. Never records a credential.**

---

## [Practice name] — dependencies

**Project reference:** [practice / Therapist Website]
**Launched:** [date]

### Domain

| | |
|---|---|
| Domain | [domain] |
| Registrar | [registrar] |
| Account held by | **The client** |
| Renewal date | [date] |
| Annual cost | [cost] — paid by the client, not the studio |

*The studio never holds the domain. If this row ever says otherwise, something
has gone wrong.*

### Hosting

| | |
|---|---|
| Host | Netlify |
| Account | Studio, while Website Care is in place |
| Cost | Included in Care |
| On leaving | The built files run on any static host. See the handover README. |

### Source

| | |
|---|---|
| Repository | Studio GitHub organisation, one repository for this client |
| Client's copy | In the handover pack, with full history |
| Build | [command] — see the handover README |

### Fonts and images

| Asset | Licence | Held by | Cost |
|---|---|---|---|
| [typeface] | [licence] | [studio / client] | [cost] |
| [image] | [licence and source] | [studio / client] | [cost] |

*Anything licensed to the studio rather than the client must be named here, so
that a future developer knows what does not travel with the site.*

### Care

| | |
|---|---|
| First year included until | [launch date + 12 months] |
| Ask about continuing by | [launch date + 11 months] |
| Then | £29/month, no minimum term |

### Anything else the site touches

[Forms, embeds, third-party scripts — or "nothing".]

---

## Why this exists

Two reasons, both practical. A client leaving needs to know what the site depends
on, what it costs and whose account it is on. And if the studio is unavailable,
this sheet tells whoever helps them where everything is — which is most of what
the continuity arrangement actually needs.
