# Declining an enquiry

The service page promises that if you are not the right person, you will say so.
That promise is worth more than the work you would have taken reluctantly, and
it is much easier to keep if you are not writing it from scratch at the time.

Say it early, say it plainly, and do not pad it with reasons that are not true.

---

> Subject: Your website
>
> Hello [name],
>
> Thank you for writing, and for telling me about [practice].
>
> I do not think I am the right person for this one. [One honest sentence. It is
> usually one of: the work you want is outside what I do; what you need is a
> different kind of help; I do not have capacity to do this properly in the
> timescale you need.]
>
> [Where you can, one useful sentence: what you would look for instead, or what
> you would do first.]
>
> I am sorry not to be more help, and I hope it goes well.
>
> Alexander

---

**Do not** offer a reduced version of the service to avoid saying no. There is
one offer. A smaller version of it does not exist, and inventing one for a client
you already doubt is how a bad project starts.
