# Requesting approval of the finished website

**This is the message that releases £495.** Clause 11 says the balance is
triggered by the client's explicit written approval, never by the studio
declaring the work finished. So the reply has to be unambiguous.

Word it so that "yes" is a complete answer and anything else is visibly not
approval.

---

> Subject: [Practice] — ready for your approval
>
> Hello [name],
>
> The website is finished and ready for you to approve. You can see it here:
> [preview address]
>
> **Before you approve, please check the facts.** These are public statements
> about your practice and you are the only person who can confirm they are
> right:
>
> - your qualifications, memberships and any registration numbers
> - your fees and session length
> - how and where you work
> - your contact details, exactly as they should appear
>
> **What approval means.** It confirms you have checked those details and are
> happy for the site to go live as it stands. It is also the point at which the
> remaining £495 is invoiced. The site goes live once that payment has arrived.
>
> **If you would like changes**, tell me — if you have a revision round left, say
> so and send one complete list rather than approving.
>
> If you are happy, please reply with: **I approve the website as it stands.**
>
> Alexander

---

## After approval

1. File the approval reply. It is the trigger and the evidence.
2. Raise the £495 invoice — next number in the `AW-` sequence, same project
   reference as the deposit invoice. Due within 14 days.
3. **Do not launch before the payment arrives.**
4. On payment: launch, then complete the handover the same day
   (`06-launch-handover-record.md`). Handover is not optional and not on request.
