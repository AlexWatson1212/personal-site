# The other messages, and the records

Short forms for the remaining points in a project where something has to be sent
or recorded. None of these forms a contract; the two that matter for money are
`01-acceptance-scope-and-price.md` and `03-approval-request.md`.

---

## Questionnaire covering note

Sent after the £500 has arrived.

> Subject: [Practice] — the questionnaire
>
> Hello [name],
>
> Your first payment has arrived, thank you. Here is the questionnaire:
> [link]
>
> It takes most people about an hour. You do not need to have your website
> planned — working out the structure is my job, and several questions exist
> precisely so you do not have to.
>
> Nothing you type is sent anywhere by the page itself; when you finish it
> assembles your answers for you to copy or open in your email.
>
> Send it back with your words, images and logo when you have them. I will tell
> you what is missing rather than guessing, and confirm your start date in
> writing once everything is here.
>
> Alexander

## Missing materials

> I have your questionnaire, thank you. Before I can confirm a start date I need:
>
> - [item]
> - [item]
>
> Nothing has begun yet — the project starts when these arrive and I confirm the
> date in writing. That is deliberate: starting on an incomplete brief is how a
> three-week project becomes a three-month one.

## Start date confirmation

> Everything has arrived and I have checked it. **Your project begins on [date]**
> and I expect to have the first version with you in [three to five] weeks.
>
> The next thing you will see from me is the Direction Note — a short written
> note setting out what I have understood and where I intend to take this. You
> approve that before I build anything.

## Revision round

> Subject: [Practice] — round [one/two]
>
> The website is ready for you to look at: [link]
>
> Please send **one complete list** rather than notes as you find them — that is
> what makes a round work, and it is why two rounds are enough.
>
> Look at the whole thing: the words, the structure, how it reads on a phone,
> and whether the facts are right.
>
> This is round [one of two / two of two]. [If two: after this the website is
> finished and I will ask you to approve it.]

**If a request falls outside a round** — a new page, a different direction, a new
service needing its own words — say so before doing it:

> Two of these are revisions and I will make them. [Item] is a new [page /
> section / service], which is outside the two rounds. I can quote for it
> separately — it would be [£X] — or leave it and we carry on. Tell me which.

## When the website does not match the approved Direction Note

**Draft — requires UK legal review.** The principle below is the studio's
operational position. It is not drafted contract language, the service terms do
not yet say it in these words, and it must not be described to a client as a
contractual right until the wording has been settled by a solicitor.

The principle: **correcting a departure from the approved Direction Note is not a
revision round.**

A revision round is the client changing their mind, or seeing the finished thing
and wanting it different. That is what the two rounds are for, and using one is
normal. A non-conformance is different — the studio built something other than
what the client approved. The client already paid for the thing they approved.
Making it match is finishing the work, not doing more of it.

So:

- the correction is made at no charge, and it does not consume a round;
- it is recorded as a non-conformance, not as feedback, so the two counts stay
  honest and the pattern is visible if it happens twice;
- the test is the Direction Note itself, in writing, as approved — not what
  anybody remembers intending.

Where it is genuinely arguable — the Direction Note was silent, or open enough to
carry both readings — say so rather than deciding it silently in either
direction:

> The Direction Note doesn't settle this either way, so I'd rather agree it than
> assume. I can treat it as a correction and make it now, or as part of round
> [one/two]. My view is [X]. Tell me which you'd prefer.

Ambiguous work is identified and agreed **before** it is done. No surprise
invoices, and equally no quiet absorption of work that was really a change of
mind — both of those make the next conversation harder.

## Care renewal — month eleven

Diarise at launch + 11 months. Clause 12 commits the studio to asking.

> Your first year of Website Care ends on [date].
>
> It has covered hosting, the certificate, updates, fixing anything that broke,
> and keeping your fees and details current.
>
> If you would like it to continue it is £29 a month, no minimum term, and you
> can stop it whenever you like. If you would rather not, that is completely
> fine — I will send you everything you need to host the site elsewhere and give
> you at least thirty days before it comes off my hosting. Your domain is in
> your own name either way.

---

## Time recording

For the first 3–5 real projects, record time by project across seven categories:

Practice Clarity · visual identity · content/copy · design · development ·
revisions · administration

**This is to find out whether £995 works, not to bill anyone hourly.** Do not
change the price on estimates. Review it after 3–5 completed projects against
what was actually recorded.

FreeAgent has project time tracking; use it rather than adding another tool.

## The five documents that are the commercial record

1. The accepted scope-and-price email
2. The terms PDF that email attached
3. The £500 invoice
4. The written approval
5. The £495 invoice

Keep them together per client. That is the whole evidential record of a project.
