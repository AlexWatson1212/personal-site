# Professional indemnity — describing the activities to a broker

**Not yet obtained.** Cover is to be in place before client #1.

A policy is priced and, more importantly, *applied* against the activities you
describe. The risk is not paying too much. It is describing the studio narrowly,
having a claim arise from the part you left out, and finding it excluded.

**Do not name a level of cover here.** That is a conversation with a broker who
knows the trade.

---

## What the studio actually does

Describe all of it. Every line below is something the studio performs for a fee.

**Website design and development**
- Designing and building websites for therapists and counsellors in private practice
- Original visual design: layout, typography, colour, and a simple typographic
  wordmark where the site needs one
- Writing and editing client-supplied copy for clarity — not copywriting from
  scratch, but editorial judgement applied to text that will be published
- Front-end development, accessibility and performance work
- Essential on-page SEO: titles, descriptions, headings, alt text, sitemaps

**Strategic and advisory work**
- Practice Clarity: working out who a practice is for and what its website needs
  to say, before anything is designed. This is advisory work and is included in
  the fee rather than sold separately — it should be described, not omitted
  because it carries no separate price.
- A written Direction Note the client approves before the build begins

**Hosting, maintenance and continuing care**
- Hosting client websites on studio infrastructure
- Deployments, dependency and security updates, TLS certificates
- Correcting faults in the website or its deployment
- Keeping published factual information up to date — fees, availability, contact
  details, qualifications
- Assisting with domain and DNS changes
- Uptime monitoring *(intended; not yet configured)*

**Handling of client material and personal data**
- Receiving, storing and publishing client-supplied copy, photographs and logos
- Holding client business contact details and professional registration details
- Publishing statements of professional qualification and fees supplied by the
  client, which the client is contractually responsible for the accuracy of
- Storing project material in cloud services and per-client code repositories
- Providing a handover pack containing the client's site, content and instructions

**What the studio does not do** — say this too, because it narrows the risk
honestly:
- No therapy, counselling or clinical work of any kind is provided through the
  studio, and no client clinical material is held or requested
- No marketing, advertising, SEO campaigns or directory management
- No payment processing; no card data is ever handled
- No email hosting or mailbox provision
- No booking, membership, e-commerce or client-portal systems

## Facts a broker will ask for

- Sole trader, no employees
- Not VAT registered
- Expected turnover — from your own figures
- Typical contract value: £995, plus £29/month optional care
- Clients: UK therapists and counsellors in private practice
- Contracts are in writing under published terms *(currently under legal review)*
- Liability position: clause 16 currently claims no cap. Say so. A broker should
  know the contract does not limit liability, because that is exactly what the
  policy would be standing behind.

## Also ask about

- **Cyber and data liability**, given the studio holds client personal data and
  hosts live websites
- Whether cover responds to a claim arising from **published content** the client
  supplied and warranted
- Whether **run-off cover** is available, and what it costs — relevant to the
  continuity arrangement, since claims can arise after the studio stops trading
