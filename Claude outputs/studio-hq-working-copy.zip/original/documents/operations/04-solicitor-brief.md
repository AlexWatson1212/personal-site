# Solicitor brief — Alexander Watson Studio

**Not yet sent.** A solicitor has not been identified or instructed. This is the
brief to send once one is.

**What is wanted:** a targeted, fixed-fee review by a UK solicitor experienced in
commercial contracts, consumer contracts and online services — not a new legal
framework written from scratch. The objective is not abstract answers. It is to
know what amendments and process changes are required so that the terms can be
put into force and the studio can safely accept its first £995 client.

Data-protection questions that the ICO can authoritatively answer are in
`05-ico-question-list.md` and are deliberately not repeated here. Escalate one of
those to the solicitor only if the ICO's answer leaves genuine ambiguity
affecting the contract or the business risk.

---

## The business, briefly

- Sole trader, UK, not VAT registered, no employees.
- One service: a £995 website for therapists in private practice.
- £500 invoiced on acceptance, paid by bank transfer before work begins.
  £495 invoiced after the client approves the finished website, due within
  14 days; the site launches once it has been received.
- No online checkout, no card payments, no Stripe.
- Roughly three to five weeks from a confirmed start date.
- Two consolidated revision rounds. Written communication by default.
- Practice Clarity — the work of understanding the practice — is inside the
  price, not an add-on.
- First twelve months of Website Care included; £29/month optional after that.
- Clients may be buying as consumers or for their business. The studio does not
  assume which.

## Documents for review

Published at alexanderwatson.co.uk:

- Therapist Website Service Terms — `/service-terms/practice-website/`
- Cancellation and refund information — `/cancellation-and-refunds/`
- Privacy notice — `/privacy/`
- Website terms and conditions — `/terms/`
- The service page the terms refer to — `/services/practice-website/`

All four legal pages currently carry a notice saying the wording has not been
reviewed by a solicitor.

---

## The questions

### 1. Can these terms be put into force at all?

**The outcome wanted:** a list of the amendments required before the draft and
unapproved notices can be removed and an effective date set. This is the
question the others serve.

The studio will not contract on terms visibly marked draft. Until this is
answered, no client can be accepted.

### 2. Clause 13 — the design-system licence

The commercial intention, which has never been drafted:

1. The licence is perpetual and does not end when Website Care ends.
2. The client may appoint another developer to maintain or modify their website.
3. It covers that one website for that practice. A second website needs a new
   licence.
4. Resale or redistribution of the underlying design system is not permitted.

The published clause 13 is a reconstruction of that intention, not drafted
wording. **Outcome wanted:** wording that achieves those four things.

### 3. Clause 16 — liability

Clause 16 currently states that no cap on liability is claimed. The studio is a
sole trader, so liability is personal and unlimited. Professional indemnity cover
will be obtained before the first client.

**Outcome wanted:** advice on whether a cap should be drafted, and if so the
wording, given the fee is £995 and the client may be a consumer.

### 4. Payment flow — six specific interactions

These follow from the move to invoice and bank transfer, and each is a question
about the existing wording rather than a request for new drafting.

**(a) An invoice before a contract exists.** Clause 4 forms the contract on
acceptance *and* payment. The £500 invoice is therefore issued into a gap where
the client has accepted in writing but is not yet bound. Should the terms say
whether that invoice is part of the offer or a demand under a formed contract,
and what the position is if a client accepts and never pays?

**(b) The cooling-off period and starting work.** If the contract forms on
payment and work begins promptly after, the work happens inside a consumer's
14-day cancellation window. The cancellation page anticipates this — *"if you
have asked me to begin during that period… you can be asked to pay a
proportionate amount"* — but relying on it requires actually obtaining the
client's express request to begin. **What form must that request take, and must
it be acknowledged?** This is a process question as much as a wording one.

**(c) A missing rung in the refund ladder.** The cancellation page steps through:
before the project begins / after it begins but before first delivery / after
first delivery / after launch. The current flow creates a stage none of those
describes — **approved, invoiced, unpaid, unlaunched.** The work is complete and
signed off, the site exists, and no money has arrived. What is each party's
position there?

**(d) Dormancy and non-payment.** Clause 8's dormancy framework (reminder at 30
days, dormant at 60) was written for a client who goes quiet during production,
and says dormancy *"does not by itself entitle either of us to a refund."*
Applying it to an unpaid balance pauses the project but resolves neither the debt
nor the contract. Can non-payment be made consistent with dormancy, or does it
need its own route?

**(e) Quote validity against clause 3.** Clause 3 says the applicable version is
the one published *at the time you paid.* The scope-and-price offer is open for
30 days, so the published terms could change between acceptance and payment. The
studio's process now attaches a dated PDF of the terms to the acceptance email.
Should clause 3 be brought into line with that?

**(f) Late payment interest.** None is claimed. Confirm that omitting it waives
nothing, given a client may be a consumer or a business.

### 5. The Direction Note warranty

The studio wishes to state that correcting work which does not conform to the
Direction Note the client already approved is **not** one of the two revision
rounds and is not chargeable.

This is intended as a bounded quality commitment, not a satisfaction guarantee —
it cannot be triggered by a change of mind, only by a departure from what was
agreed in writing. **Outcome wanted:** wording that says that and no more.

### 6. Trader disclosure and the business address

The studio will use a standalone UK business/service-address provider rather than
a residential address. The address appears in the "between you and…" sentence of
both contracts, in the privacy notice, and on invoices.

**Outcome wanted:** confirmation that a service address of that kind satisfies
the disclosure obligations of a UK trader selling to consumers at a distance, and
anything the provider's terms must permit for it to do so.

### 7. Cancellation — two items already flagged

- Whether a model cancellation form must be provided, and its wording.
- Whether an alternative dispute resolution route should be named.

---

## What the studio needs back

Not a memorandum. For each question: the answer, the amendment required, and —
where it is a process rather than a wording matter — what the studio must
actually do differently.
