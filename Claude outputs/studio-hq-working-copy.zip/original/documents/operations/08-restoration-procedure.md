# Restoration procedure

**What this is for.** Website Care promises to correct faults in a website or its
deployment. This is the procedure for the worst version of that: the site is
broken, or gone, and it has to come back.

Written down so it is not reconstructed under pressure with a client waiting.

**Status: written, never rehearsed.** Rehearse it once against a concept site
before client #1. A procedure that has never been run is a document, not a
capability.

---

## What the studio promises, and what it does not

- Acknowledge a reported or detected problem **within one working day**, and say
  what is happening.
- **No** guaranteed repair time. **No** uptime guarantee. **No** promise of
  continuous monitoring.

Do not improvise a better promise to a distressed client. The commitment is the
acknowledgement.

---

## Where a client site lives

| Thing | Where | Who holds it |
|---|---|---|
| Source and history | Per-client repository in the studio GitHub organisation | Studio *(organisation not yet created)* |
| Deployed site | Netlify | Studio |
| Domain | The client's own registrar account | **The client, always** |
| Project documents | Studio Google Drive, one folder per client | Studio *(tier unresolved)* |
| Client's own copy | Handover pack, given at launch | The client |

The domain is the one thing the studio never holds. That is deliberate and it is
what makes everything below recoverable rather than catastrophic.

---

## Triage

**1. Establish what is actually broken.** In order, because each rules out the
next:

- Does the domain still resolve? If not, the problem is DNS or the registrar,
  not the site. Go to §4.
- Does the site load but look wrong? A bad deploy. Go to §2.
- Does it return an error, or nothing? Check the Netlify deploy log — a failed
  build leaves the previous deploy live, so a *failed* build is usually not the
  cause of a *broken* site.
- Is the certificate expired? The browser will say so plainly. Go to §5.

**2. Acknowledge.** Before fixing anything, tell the client you have it. One
working day is the commitment; ten minutes is the standard.

---

## §2 — Roll back a bad deploy

Netlify keeps every previous deploy. Restoring one is a published action in the
deploy list, not a rebuild.

1. Netlify → the site → Deploys
2. Find the last deploy that was known good
3. Publish that deploy
4. Confirm the live site in a browser, not just in the dashboard
5. Then work out what broke, in the repository, without time pressure

This is why per-client repositories and Netlify deploys matter more than backups:
the history *is* the backup, and rolling back is a click.

## §3 — Rebuild from source

If the deploy history is unusable:

1. Clone the client repository from the studio GitHub organisation
2. Build it (`README.md` in the handover pack carries the commands)
3. Deploy the built output to Netlify
4. Confirm the live site

## §4 — Domain and DNS

The domain is in the client's name and the studio does not control it.

1. Confirm with the client whether anything changed — a renewal lapse, a
   registrar transfer, a nameserver edit
2. If it has expired, only the client can renew it. Tell them plainly and help
   them do it.
3. If DNS records are wrong, talk them through the change or ask them to grant
   access temporarily

**Never ask a client for their registrar password.** Ask them to make the change,
or to add you properly.

## §5 — Certificate

Netlify renews automatically. A failure is usually a DNS record that no longer
points where it should — fix §4 first, then renew.

## §6 — Total loss

If the studio's Netlify and GitHub are both unreachable, the client's own
handover pack contains the complete source, the built files a host needs, and
instructions for deploying elsewhere. That is the floor, and it is why the launch
handover is mandatory rather than on request.

---

## After any restoration

1. Tell the client what happened, in plain words, and what stops it recurring.
2. Record it on the project.
3. If it was preventable, fix the cause, not just the symptom.
