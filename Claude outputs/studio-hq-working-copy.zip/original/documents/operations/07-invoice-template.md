# Invoice template

**Two invoices per project**, each taking the next number in one continuous
sequence, both carrying the same project reference so they are visibly related.

**Blocked:** the business address is not yet purchased and the bank account is
not yet open. An invoice cannot be issued until both exist.

**Never put bank details on the website.** They belong on the invoice only.

---

## Sequence

`AW-0001`, `AW-0002`, `AW-0003` … one continuous global sequence. No annual
reset. Every invoice takes the next number, including the second invoice of a
project the studio has already invoiced once.

Set this up in FreeAgent as the **global** sequence with the `AW-` prefix. Do not
enable contact-level or project-level numbering — those produce a separate
sequence per client and break the single sequence.

---

## What every invoice carries

| Field | Value |
|---|---|
| Invoice number | Next in the `AW-` sequence |
| Project reference | The practice name and project, e.g. *Marin / Therapist Website* |
| Invoice date | The date it is issued |
| Due date | Deposit: before work begins. Balance: 14 days from the invoice date |
| From | Alexander Watson, a sole trader, trading as Alexander Watson Studio |
| Address | *(blocked — business/service address not yet purchased)* |
| Email | hello@alexanderwatson.co.uk |
| To | Name to invoice, and billing address, as given in the acceptance exchange |
| Description | See below |
| Amount | £500 or £495 |
| VAT | **Not registered for VAT. The price shown is the amount charged.** State this explicitly — silence looks like an omission. |
| Payment method | Bank transfer. Account details, and the reference to quote. |

---

## Deposit invoice — description

> **Therapist Website — first instalment**
> £995 total, taken in two instalments. This is the first.
>
> Includes the work of understanding the practice, an original design, up to
> five core pages, the visual identity the website needs, two consolidated
> revision rounds, launch, and the first twelve months of Website Care.
>
> Payable before work begins. The project begins once the completed
> questionnaire and materials have been received and checked, and a start date
> has been confirmed in writing.
>
> Made under the Therapist Website Service Terms, version [X] dated [date].

## Balance invoice — description

> **Therapist Website — second instalment**
> £995 total, taken in two instalments. This is the second and final one.
>
> Issued following your written approval of the finished website on [date].
> Due within 14 days. The website is made live once payment has been received.
>
> Made under the Therapist Website Service Terms, version [X] dated [date].

---

## Recording

1. Raise in FreeAgent; it holds the sequence.
2. On payment, reconcile against the business account.
3. Record the payment date on the project.
4. The five documents that make up the commercial record of a project:
   the accepted scope-and-price email, the terms PDF that email attached,
   both invoices, and the written approval that triggered the second one.
   Keep them together.

## If a balance invoice is not paid

There is no interest clause and none is planned — the leverage is structural:
the website is not made live until the payment has arrived. Prolonged
non-payment follows the existing reminder and dormancy framework rather than a
separate process. *The exact wording is a solicitor question — see*
`04-solicitor-brief.md` *question 4(c) and 4(d).*
