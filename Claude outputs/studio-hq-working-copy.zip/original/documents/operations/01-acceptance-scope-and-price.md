# Acceptance — scope, price and terms

**What this is.** The email that forms the contract. Clause 4 of the Therapist
Website Service Terms says the agreement is made in writing, that this message
refers to the terms, and that a contract is formed when the client accepts it in
writing and the first instalment is paid.

Send it only after you have decided you are the right person for the work.

**Blocked until the legal review is complete.** The terms are still marked draft
and carry no effective date. Do not issue this email against terms described as
unapproved. See `04-solicitor-brief.md`.

---

## Before you send

- [ ] You have read the enquiry and decided you can do the work well
- [ ] You have the billing details: name to invoice, billing address, invoice email
- [ ] You have a version and date to cite for the terms
- [ ] You have attached a dated PDF of the terms as they stand today

---

## The email

> Subject: Your website — scope, price and terms
>
> Hello [name],
>
> Thank you for telling me about [practice]. I have read it properly and I would
> like to do this work.
>
> **What I would build.** [Two or three sentences: what you have understood about
> the practice, which design in the collection it starts from, and what the site
> has to do for the people arriving at it. This is not the Direction Note — it is
> the shape of the job.]
>
> **What it costs.** £995 in total. £500 to begin, and £495 once you have
> approved the finished website, before it goes live. That includes the work of
> understanding the practice, an original design for it, up to five core pages,
> the visual identity the site needs, two consolidated rounds of revisions,
> launch, and the first twelve months of Website Care.
>
> **How long it takes.** Three to five weeks from the confirmed start date. The
> start date is confirmed in writing once your questionnaire and materials have
> arrived and I have checked them — not on the date you pay.
>
> **The terms.** This offer is made under the Therapist Website Service Terms,
> version [X] dated [date], which I have attached as a PDF so you have the exact
> wording. The cancellation and refund information and the privacy notice are
> part of them. Please read them before you agree.
>
> **This offer is open for 30 days.**
>
> If you would like to go ahead, reply to say so and I will send the first
> invoice for £500. Payment is by bank transfer; the account details are on the
> invoice. Work begins once it has arrived.
>
> If anything here is not what you expected, tell me and I will change it or say
> plainly that I am not the right person.
>
> Alexander

---

## After they accept

1. Record the acceptance date and file the reply.
2. Raise the £500 invoice — next number in the `AW-` sequence.
3. Keep the accepted email, the attached terms PDF and the invoice together with
   the project record. Those three documents are the contract.
