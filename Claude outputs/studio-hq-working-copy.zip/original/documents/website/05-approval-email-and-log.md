# Stage 05 — Client approval

Two things: an email that is short and warm, and a log that is exact. The email
is for the client. The log is so that in four months nobody argues about what was
agreed.

---

## The email

Send the brief, the approved copy and the Brand System Sheet as attachments. Do
not restate them in the email — summarise the direction in a few lines and ask
for one clear thing.

**The copy is already approved by the time this email goes out.** Stage 03b
closes before Stage 04 begins, so this email confirms the direction as a whole
rather than asking for a first reaction to the words. If the copy has not been
approved, the Brand System Sheet should not have been written yet.

> **Subject:** Your direction — ready for you to look at
>
> Hi [Name],
>
> Here are the documents from our call: the practice brief, the site copy you
> approved on [date], and the visual system built to fit it.
>
> The short version. We're building around [the one sentence that describes who
> they help and what changes]. The look is [three or four words — e.g. editorial,
> grounded, unhurried]: [surface colour] as the main surface, [contrast colour]
> for the sections that need to land, [type direction]. Your own photography
> carries it — no stock imagery anywhere.
>
> Two things I decided and want you to know about:
> - [Decision, and the reason in one clause]
> - [Decision, and the reason in one clause]
>
> And [n] things I still need from you before we can launch: [list them plainly].
>
> If the direction is right, reply and say so — that's all I need to start
> building. If something feels off, tell me which part. It is much cheaper to
> change now than later, and being told "not quite" is genuinely useful.
>
> One thing worth knowing: your two revision rounds cover the words and the
> design together, so a change to either uses the same round. Send everything in
> one go rather than as you think of it and you will get more from them.
>
> [Sign-off]

**Rules for this email.** No enthusiasm the work has not earned. No "excited to
share". No asking them to "review and provide feedback at their earliest
convenience" — ask for a yes or a specific objection. Name the decisions you made
on their behalf; a client who discovers those later feels managed.

---

## Decision log

| Field | Value |
| --- | --- |
| Client | |
| Brief version sent | |
| Brand System Sheet version sent | |
| **Date sent** | |
| **Date approved** | |
| Approved by (name, and how — email, call, in writing) | |

### Decisions made

| # | Decision | Made by | Date | Reason |
| --- | --- | --- | --- | --- |
| 1 | | | | |
| 2 | | | | |

### Documented extensions to the Brand System Sheet

Anything added outside the approved sheet, with the flag raised at the time.

| Date | Extension | Reason | Permitted scope | Client told? |
| --- | --- | --- | --- | --- |
| | | | | |

### Unresolved questions

| # | Question | Owner | Blocks | Needed by | Closed |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

### Approval covers three documents

Recorded separately because they are approved at different moments and the dates
matter when a change is later disputed.

| Document | Version | Sent | Approved | Approved by | Method |
| --- | --- | --- | --- | --- | --- |
| Practice Clarity brief | | | | | |
| Copy Approval — sitemap, wording, titles and descriptions | | | | | |
| Brand System Sheet | | | | | |

The copy approval lives in `03b Copy Approval/02b-copy-approval.md` and is the
authoritative record of the words, including every approved change after this
date. This table records only that it happened.

### Changes requested at approval

| # | Requested | Response | In scope? | Actioned |
| --- | --- | --- | --- | --- |
| | | | | |

> Scope note: revisions to the *direction* are expected and included. A second
> direction is not a revision — it is a new Stage 04, and it is priced.
> Copy and visual changes draw on the same two consolidated rounds; a request
> that changes the words and the design is one round, not two.
