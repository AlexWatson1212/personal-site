# Stage 02 — Intake

Two documents: what the client fills in before the call, and what the studio asks
during it. The questionnaire gathers facts. The call gathers the things people
only say out loud.

---

## Part A — Client questionnaire

**Client-facing.** Sent with the engagement confirmation.

> **Before you start**
>
> Sixteen questions. Twenty minutes is enough, and rough answers are more useful
> to me than tidy ones — write the way you would say it, not the way you think a
> website should sound.
>
> If a question does not apply, write "not applicable" and move on. There are
> eight optional questions at the end. Skip them if you are short of time; answer
> them if you find you have things to say.

### The practice

**1.** What is the practice called, and where are you in your career — private
practice, placement, training, or somewhere between? If your course, placement or
insurer requires exact public wording, give it to me word for word.

**2.** Where do you work: a location, online, or both? Is that current or
intended?

**3.** What is your training and modality, and which professional body are you
registered with or working towards? Attach or link the wording they permit you to
use.

**4.** What is your session fee, and do you want it shown publicly?

### The people you work with

**5.** Describe one person you work well with. Not a category — one person, as if
you were describing them to a colleague.

**6.** What is going on in someone's life in the weeks before they contact you?
What is the last thing that happens before they decide to look for a therapist?

**7.** What have they usually already tried?

**8.** What is different for them after a period of work with you? Plain terms,
and only what you have actually seen.

**9.** Who do you *not* work with, or not work well with?

### How you work

**10.** What actually happens in a first session with you?

**11.** What do you do that another therapist with your training might not?

**12.** What are your boundaries — hours, contact between sessions, cancellation,
and anything you will not do?

### Tone

**13.** Name two or three websites, from any field, that feel right to you, and
say what it is about each. Then name one that feels wrong, and why.

**14.** Which words or phrases should never appear on your site?

### Practical

**15.** What do you want a visitor to *do* — email, form, phone, booking system?
And how quickly do you realistically reply?

**16.** What do you already have: photography, a logo, existing brand work, a
domain? Attach what you can, and say where the domain is registered.

---

### Optional — if useful

Skip these entirely if you are short of time. They tend to be where the good
lines come from, so answer any that you find yourself with something to say
about.

**O1.** What made you decide to do this now?

**O2.** What do clients get wrong about you before they meet you?

**O3.** What are people afraid you will say?

**O4.** Tell me about a piece of work you were proud of. What changed?

**O5.** Where does your way of working get uncomfortable, and for whom?

**O6.** What would make you regret having a website? What must not be on it?

**O7.** Is there anything you are worried about — being visible, being
misunderstood, saying the wrong thing?

**O8.** What do you want a visitor to understand before they contact you?

---

## Where these questions came from

The first version of this questionnaire asked 22 numbered questions. It was
compressed to 15 required plus 7 optional, and two useful questions were lost in
the compression rather than dropped on purpose. Both have been restored: Q7 as
required, O8 as optional. Sixteen required plus eight optional is the live set.

Recorded question by question so that nothing has to be worked out again from
memory. The archived original is
`Archive/Superseded drafts/01-intake-questionnaire (22-question version, superseded).md`.

| Old | Old question | Now | Decision |
| --- | --- | --- | --- |
| 1 | What is the practice called, and is that name settled? | Q1 | **Merged** into Q1 with old 2. The name and the career stage are one question because the answer to one changes the wording of the other. |
| 2 | Private practice, placement, training? Exact public wording required? | Q1 | **Merged** — see above. The exact-wording request is preserved verbatim. |
| 3 | Where do you work — location, online, or both? Current or intended? | Q2 | **Retained**, wording unchanged. |
| 4 | Session fee, and shown publicly? | Q4 | **Retained**, wording unchanged. |
| 5 | What modality or modalities are you trained in? | Q3 | **Merged** into Q3 with old 6. Training and registration arrive together and the body's permitted wording depends on both. |
| 6 | Which professional body, and their permitted wording? | Q3 | **Merged** — see above. |
| 7 | Describe one person you work well with. | Q5 | **Retained**, wording unchanged. |
| 8 | What is going on in the weeks before they contact you? | Q6 | **Retained**, and strengthened with "what is the last thing that happens". |
| 9 | **What have they usually already tried?** | **Q7** | **Restored in this pass.** Lost in the compression. It is the question that separates "I need help" from "I have tried three things and none of them worked", and that distinction is most of the recognition section. |
| 10 | What is different after a period of work with you? | Q8 | **Retained**, and tightened to "only what you have actually seen". |
| 11 | Who do you *not* work with? | Q9 | **Retained**, wording unchanged. |
| 12 | What actually happens in a first session? | Q10 | **Retained**, wording unchanged. |
| 13 | What do you do that another therapist might not? | Q11 | **Retained**, wording unchanged. |
| 14 | What are your boundaries? | Q12 | **Retained**, wording unchanged. |
| 15 | **What do you want a visitor to understand before they contact you?** | **O8** | **Restored in this pass**, as optional. It overlaps Q5–Q8 for a client who answers those well, and it is a gift from a client who does not — which is the definition of an optional question here. |
| 16 | Name two or three websites that feel right. | Q13 | **Merged** into Q13 with old 17. Asking for the right and the wrong in one question gets a comparison rather than two lists. |
| 17 | Name one that feels wrong. | Q13 | **Merged** — see above. |
| 18 | Which words should never appear on your site? | Q14 | **Retained**, widened to "words or phrases". |
| 19 | What do you want a visitor to *do*? | Q15 | **Merged** with the old Part B "how quickly do you actually reply?", because the action and the reply time are one promise. |
| 20 | Photography, logo, existing brand work? | Q16 | **Merged** into Q16 with old 21. |
| 21 | Do you own a domain? Where is it registered? | Q16 | **Merged** — see above. |
| 22 | Anything you are worried about? | O7 | **Retained** as optional. It is the question people answer best out loud, so the call asks it again. |

**Deliberately not restored.** Nothing from the 22 was removed outright. Every
old question is either retained, merged into a retained one, or restored above —
which is the answer to the question of whether the four "dropped" questions were
dropped on purpose. Two were merges recorded here; two were losses, and both are
back.

**Added since the 22-question version**, and kept: O1 *what made you decide to do
this now*, O2 *what clients get wrong about you*, O3 *what are people afraid you
will say*, O4 *a piece of work you were proud of*, O5 *where your way of working
gets uncomfortable*, O6 *what would make you regret having a website*. All six
came up the old Part B call structure and were promoted to optional written
questions so a client who prefers writing to talking can answer them.

---

## Part B — Clarity call, 45 minutes

**Internal.** Your call structure — not sent to the client.

The returned questionnaire determines which of these get asked. Do not work
through all of them. Six good questions beat sixteen shallow ones, and anything
already answered well in Part A should not be asked again.

**Opening (5 min).** Whatever they wrote for O1 — or, if they skipped it, what
made you decide to do this now?

**The struggle (10 min).** Take me to the moment someone decides to look for a
therapist. What do they type into a search box? What are they afraid you will
say? *(Push on Q6 and Q7 — this is where most websites are vague and where recognition
is actually won.)*

**The work (10 min).** Tell me about a piece of work you were proud of, and what
changed. Where does your way of working get uncomfortable, and for whom?
*(Cross-check against Q8 — if the claim in writing is larger than the story out
loud, the writing comes down.)*

**Boundaries and risk (10 min).** What would make you regret having a website?
What must not be on it? What happens if someone in crisis lands on the page?

**Action (5 min).** What does a good enquiry look like, and what does a bad one
look like?

**Close (5 min).** Confirm the eight facts that block a launch: public wording for
training and registration, location, availability, fee, enquiry address, reply
time, any required privacy or safeguarding statements, and the domain. Read them
back and get a yes on each — this is the step that gets skipped and then costs a
week at launch.

---

## Missing-information log

**Internal.** Kept alongside the returned questionnaire. Every unanswered item is
a launch blocker until it is closed. Optional questions are not logged here —
only the sixteen and the eight launch facts.

| # | Missing item | Why it blocks | Asked on | Answer | Closed |
| --- | --- | --- | --- | --- | --- |
| | | | | | |
