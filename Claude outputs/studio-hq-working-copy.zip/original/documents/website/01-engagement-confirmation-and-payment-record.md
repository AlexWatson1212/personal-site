# Stage 01 — Engagement Confirmation and Payment Record

**Client:**
**Project:**
**Version:**
**Prepared:**

The document that turns an enquiry into a booked engagement. It states what is
being made, what it costs, when it is paid, and what the client has to supply
before it can be built. Nothing else in this system runs until this is signed.

Part A is client-facing and is issued as a PDF set in the studio document
system. Parts B, C and D are internal and are never sent.

**Issued with:** Part A of `02 Intake/02-intake-questionnaire.md`.
**Set using:** `Brand and Document System/Master Templates v1.0.pdf` — the
*Proposals and reports* application, A4 portrait, wordmark and title only on the
cover. Language follows Section 09, Voice, of the Brand and Digital Identity
Guidelines.

---

> ## ⚖ Read this before issuing
>
> **This document has not been reviewed by a solicitor and is not legal advice.**
> It is a plainly written commercial agreement drafted for a small independent
> web studio. It is not certified, approved or verified as legally sufficient,
> and nothing here should be described to a client as though it were.
>
> Clauses marked **⚖** deal with legal risk — liability, indemnity, governing
> law, dispute handling and IP transfer. They are drafted to be readable and
> proportionate, not to be authoritative. **Have a UK solicitor review every ⚖
> clause before this is issued to a paying client**, and again if the studio ever
> works outside England and Wales, takes on a client who is not a sole
> practitioner, or handles special-category personal data.
>
> Tracked as an open action in `ACTIONS.md`.
>
> **On the archived documents.** The retired Service Agreement and Statement of
> Work are indexed by name in `ARCHIVE-INDEX.md` but the files themselves are not
> present in this system. Nothing below was copied from them. Every clause was
> written fresh against the provision list the review was scoped around. When the
> originals are located, run the coverage table in `ARCHIVE-INDEX.md` against
> them and fold in anything genuinely missing — do not paste old language in
> wholesale.

---

# Part A — Engagement confirmation

**Client-facing.** Issued as a PDF, not as an email body.

## 1. What is being made

| | |
| --- | --- |
| Client / practice name | |
| Practitioner | |
| Deliverable | |
| Scope in one sentence | |

State the deliverable in the words the client will recognise, not in studio
shorthand. "A one-page website for your counselling practice, with a Practice
Clarity document and a brand system that goes with it" is a scope. "Website
build, Tier 2" is not.

## 2. What is included

| Stage | You receive | Format |
| --- | --- | --- |
| Intake and clarity call | A 45-minute call and a written record of what was agreed | Call + notes |
| Practice Clarity | A document defining your practice, the people you work with, how you work, and how the practice should be described | PDF |
| Website copy | The sitemap and every word the site will show — headings, body, calls to action, the practical facts, and the titles and descriptions that appear in search results — approved before anything is designed | Document |
| Visual identity | A brand system sheet — colour, typography, spacing, image direction, voice, accessibility — with the reasoning behind each decision, designed to the approved words | PDF |
| Website | A built, tested and launched site | Live site |
| Handover and care | A handover guide, your accounts and assets in your own name, and an agreed care arrangement | PDF + transfer |

**Quantities, stated so they are not assumed.**

| | |
| --- | --- |
| Pages, or sections on a single page | |
| Enquiry forms | |
| Consolidated revision rounds for the website | **Two.** Copy changes and visual changes share them — see §9 |
| Languages | One (British English) unless stated here |

## 3. What is not included

Written plainly, because the absence of this list is what causes the argument
four months later.

- Copywriting beyond the pages and sections listed in §2
- Photography — commissioning, shooting, licensing or retouching
- Logo design as a separate commission
- Ongoing content updates outside the care arrangement
- Third-party costs: domain registration, hosting above the free tier, fonts,
  booking systems, email hosting
- Integrations with practice-management, booking or payment systems unless named
  in §2
- Hosting, maintaining or migrating email
- Search-engine optimisation as an ongoing service, paid advertising, social
  media, analytics reporting
- Legal, regulatory or clinical wording. Privacy notices, data-retention
  statements, safeguarding statements and professional-body wording are supplied
  by you and used as supplied.
- A second visual direction. Revisions to the agreed direction are included; a
  second direction is a new stage and is priced.
- Anything not written on the approved Brand System Sheet

| Not included | If you want it | Indicative cost |
| --- | --- | --- |
| | | |

## 4. Stages and indicative timeline

Dates move when information is late. This is stated here so that it is not a
surprise later.

| Stage | What happens | Who holds it | Indicative |
| --- | --- | --- | --- |
| 01 Engagement | This document signed, deposit paid | Client | |
| 02 Intake | Questionnaire returned, clarity call held | Client, then studio | |
| 03 Practice Clarity | Brief written and sent for approval | Studio | |
| — | *You may stop here with the completed Practice Clarity document and nothing outstanding* | Client | |
| 03b Copy approval | Sitemap and all website wording written and approved | Studio, then client | |
| 04 Visual identity | Brand System Sheet written to the approved copy and sent for approval | Studio | |
| 05 Approval | Brief, copy and Brand System Sheet all approved in writing | Client | |
| 06 Build | Build, QA, launch | Studio | |
| 07 Handover and care | Accounts transferred, guide issued | Studio, then client | |

**The clock stops when I am waiting on you.** A stage that is blocked on
information from you does not consume studio time and does not advance the
timeline. Blocked items are recorded with the date they were first requested.

Timings are estimates made in good faith, not fixed delivery dates. Where a date
genuinely matters to you — a course start, a placement, an insurance renewal —
say so here and it will be planned around rather than hoped for.

| Fixed date that matters | Why | Agreed |
| --- | --- | --- |
| | | |

## 5. Price and payment schedule

| | |
| --- | --- |
| Total fee | |
| VAT position | |
| Currency | |

| # | Payment | Amount | Due | Paid |
| --- | --- | --- | --- | --- |
| 1 | Deposit — confirms the booking and the start date | | On signature | |
| 2 | On approval of the Practice Clarity brief, the website copy and the Brand System Sheet | | Stage 05 | |
| 3 | On launch, before handover | | Stage 07 | |

**Terms**

- Payment by bank transfer. Details on the invoice, never in an email body.
- Invoices are due within 14 days.
- The deposit reserves the start date and is non-refundable once Stage 02 has
  begun.
- Work pauses on an invoice more than 14 days overdue rather than continuing
  unpaid. You will be told at least 7 days before it pauses, not after.
- Ownership of the finished work transfers on receipt of the final payment
  (§13). Until then it is licensed to you for review only.
- The site is transferred into your own accounts at handover, and handover
  follows the final payment.
- **⚖ Late payment.** Statutory interest and recovery costs may apply to
  commercial debts under the Late Payment of Commercial Debts (Interest) Act
  1998. Whether to state a rate here, and what rate, is a question for the
  solicitor review — do not assert one without it.

## 6. Third-party services and costs

Costs that are yours, paid by you, in your name. Listed so that no renewal
arrives unexpectedly.

| Service | Purpose | Who pays | Approximate | Renews |
| --- | --- | --- | --- | --- |
| Domain registration | | Client | | Annually |
| Hosting | | | | |
| Email | | | | |
| Fonts / licences | | | | |
| Booking or payment system | | | | |

**How third parties are handled.**

- Accounts are opened in your name, on your card, from the day they are created.
  Where the studio sets one up on your behalf it is as a delegate, never as owner
  (`Registers/client-access-and-asset-register.md`).
- You are bound by each provider's own terms, which are theirs and not mine.
- The studio does not resell, mark up or take commission on any third-party
  service.
- **A third-party service failing, changing its terms, changing its pricing or
  closing is outside the studio's control.** If that breaks something, fixing it
  is chargeable work unless the care arrangement covers it.
- No third-party cost is incurred on your behalf without your agreement in
  writing first.

## 7. Your responsibilities

The engagement depends on things only you can supply. Listed here so that a
delay has an owner.

**You agree to:**

- Provide the eight launch facts below, and your privacy, data-retention and
  safeguarding statements, by the dates agreed
- Respond to approval requests within **[n] working days**
- Give consolidated feedback — one collected response per round, not a stream
- Confirm that any text, image, logo or font you supply is yours to use, and
  that you hold the necessary permission or licence
- Confirm professional-body, training, registration and insurance wording is
  exactly what those bodies permit
- Keep account credentials secure and not share studio-issued access with others
- Nominate one person who can give approval. Where more than one person is
  involved, approvals still come from that one named person.

| | |
| --- | --- |
| Approver name and role | |
| Agreed response time | |

**The eight facts that block a launch.** Asked for here, at the start, because
every one of them has held up a launch somewhere.

| # | Item | Why it matters | Due by | Received |
| --- | --- | --- | --- | --- |
| 1 | The exact public wording your course, placement or insurer requires | Wrong wording is a professional risk, not a style preference | | |
| 2 | The professional body wording and logo permission you actually hold | No mark goes on the site without written permission | | |
| 3 | Location wording, and whether it is current or intended | | | |
| 4 | Availability | | | |
| 5 | Session fee, and whether it is shown publicly | | | |
| 6 | The enquiry address the site will use | A personal address is a decision, not a default | | |
| 7 | Realistic reply time | It is published, so it has to be true | | |
| 8 | The domain, and where it is registered | | | |

Also needed: any photography, logo or existing brand work you already hold.

## 8. Delays, silence and dormant projects

Studio time is booked in advance, so a project that stops does not simply resume
where it left off.

| | |
| --- | --- |
| Normal response expected | **[n] working days** |
| First chase | After [n] working days, by email |
| Second chase | After a further [n] working days |
| Project moved to dormant | After **[n] weeks** with no substantive response |

**What being dormant means.** The project is released from the schedule.
Restarting is subject to availability and may need a new start date. Stages
already completed remain payable and are invoiced at that point if they have not
been already. Nothing is deleted, and your materials stay held under §14 until
the retention period ends.

**Restarting.** A dormant project restarts on written agreement. Where more than
**[n] months** have passed, the confirmed facts in §7 are re-checked before any
work resumes — fees, availability and registration wording go stale, and
publishing a stale fact is a professional risk to you.

| | |
| --- | --- |
| Restart fee, if any | |
| Are original prices held? | |

Delay caused by the studio works the same way in reverse: you will be told as
soon as it is known, given a revised date, and not billed for a stage that has
not been delivered.

## 9. How revisions work

- **Two consolidated rounds for the website.** Revisions to what has been
  proposed are expected and included. Tell me which part is wrong and why.
- **Copy and visual changes share those two rounds. They are not separate
  allowances.** A round is one collected response, and it may contain changes to
  the words, to the design, or to both — it is still one round. Copy changes are
  not free because they are "only words": the brand system is designed to fit the
  approved copy, so a longer heading or a fourth call to action moves the design
  as well.
- **Corrections of fact are not revisions** and are not counted — a wrong fee, a
  misspelled name, or wording a professional body requires.
- **After Stage 05 approval:** the approved Brand System Sheet governs the
  build. Something genuinely needed that is not on it becomes a *documented
  extension* — written into the sheet with its reason, its one permitted
  location and its measured contrast, and you are told at the time.
- **A second direction** is not a revision. It is a new Stage 04 and it is
  priced.
- **Reopening an approved stage** is chargeable at **[rate]**, quoted before any
  work starts. Approval is what lets the next stage be built on solid ground; if
  the ground moves, the work above it moves too.

## 10. What the site is tested on

Stated so that "it looks wrong on my machine" has an agreed answer.

**Tested on, and supported:**

| | |
| --- | --- |
| Desktop browsers | Current and previous major release of Chrome, Edge, Firefox and Safari |
| Mobile browsers | Current Safari on iOS, current Chrome on Android |
| Screen widths | 320px to 1920px, with no horizontal scrolling at any width |
| Assistive technology | Full keyboard operation, visible focus, correct heading order, labelled form fields |
| Reduced motion | Honoured |

**Not supported.** Browsers outside the versions above, Internet Explorer, beta
or preview browser builds, browsers with JavaScript disabled beyond graceful
degradation, and pages rendered inside third-party in-app browsers that rewrite
content. Text may be a pixel or two different between operating systems — that
is normal rendering behaviour, not a defect.

**Accessibility.** The site is built and checked against WCAG 2.2 level AA for
the pages delivered: contrast measured per pairing, keyboard operable, no
meaning carried by colour alone. This is a build standard the studio works to and
verifies at QA. **It is not a certification, an audit, or a guarantee of legal
compliance**, and it covers only the pages as delivered — content you add later
is yours to keep to the same standard. If you need a formal accessibility audit,
that is a separate commission by a specialist.

## 11. After launch

**Defects window.** For **30 days** after launch, anything that does not work as
specified is fixed free of charge. That means broken links, a form that fails to
deliver, a layout that breaks on a supported browser, a factual value that does
not match what you confirmed at Stage 03.

**Not a defect:** a change of mind, a new requirement, new content, a fact that
has changed since you confirmed it, or a fault in a third-party service (§6).

**After the window,** support runs through the care arrangement in
`07 Handover and Care/07-website-handover-and-care-guide.md`, or is quoted as
individual work. Care is agreed at handover; it is not automatic and it is not
included in this fee unless stated in §2.

| | |
| --- | --- |
| Care offered from launch? | |
| Indicative care fee | |
| Response time under care | |

**No uptime guarantee.** The site is hosted on your own account with a
third-party provider. Availability is theirs, not the studio's, and no uptime
figure is promised here.

## 12. Ending the engagement

Either of us may end this engagement. What happens next depends on why.

**You may end it at any time, for any reason**, with notice in writing. Stages
completed or in progress are payable. The deposit is not returned once Stage 02
has begun.

**Either of us may end it immediately** if the other:

- fails to pay, or fails to supply essential information, for more than
  **[n] days** after a written reminder
- asks for, or insists on, something that would be dishonest, unlawful, or in
  breach of a professional body's requirements
- behaves abusively

**The studio may end it** if it becomes clear the work cannot be delivered
honestly — for example if the only site you will accept would overstate your
training, registration or outcomes. Fees for stages not delivered are refunded.

**⚖ Events outside either party's control.** Neither of us is in breach for a
delay caused by something genuinely outside our control — serious illness,
bereavement, infrastructure or supplier failure. The affected party tells the
other promptly, and the timeline moves. If it lasts more than **[n] weeks**,
either of us may end the engagement, with completed stages payable and
undelivered stages refunded.

**On ending, whatever the reason,** you receive everything paid for: completed
documents, any built files, your photography masters, and confirmation that
studio credentials have been revoked. Nothing is withheld as leverage.

## 13. ⚖ Ownership and intellectual property

**What becomes yours, on receipt of the final payment:**

- The final copy written for your site, as approved at Stage 03b
- The Practice Clarity document and the Brand System Sheet
- The site files as delivered, and the design as applied to your site
- Anything you supplied — which was always yours

Ownership transfers on final payment. Before that, the work is licensed to you
for review only and may not be published or used elsewhere.

**What stays with the studio:**

- The studio's own methods, templates, checklists, process documents and this
  system
- The Alexander Watson identity — wordmark, typefaces, palette and layout system.
  These belong to the studio and are used to make your work; they do not travel
  to you and never appear on your site.
- Working files, notes and drafts, which are retained but not delivered

**What belongs to somebody else.** Fonts, stock assets, plugins and third-party
code are licensed, not owned. Their licences are recorded in
`Registers/client-access-and-asset-register.md` §7 and they pass to you on the
terms of those licences, which may limit what you can do with them.

**⚖ You confirm** that anything you supply — text, images, logos, testimonials,
professional-body marks — is yours to use or properly licensed, and that you hold
consent for any identifiable person in a photograph.

**⚖ Indemnity.** You agree to cover the studio against a third-party claim
arising from material you supplied or wording you insisted on. This clause needs
solicitor review before issue: its scope, its cap and whether it is proportionate
for engagements of this size are all judgement calls that should not be made
here.

**Portfolio.** The studio may show the work as a portfolio piece, including the
Practice Clarity and Brand System documents, unless you say otherwise:
☐ Do not show this work publicly.

## 14. Confidentiality and data

- **Confidentiality.** Nothing you tell me about your practice, your clients or
  your circumstances is repeated or published. This continues after the
  engagement ends.
- **Your clients' data.** No client-identifying material of yours is ever used in
  copy, imagery or examples. If something identifying arrives in a questionnaire
  answer or a call note, it is removed at the point it is noticed.
- **Your personal data held by the studio** — what is held, where, why, and for
  how long — is recorded in `Registers/client-access-and-asset-register.md` §9,
  with a stated retention period and deletion date. You can ask for a copy of
  that record, or for deletion, at any time.
- **⚖ UK GDPR.** For your own site's enquiry data you are the controller; the
  studio processes it only to build and test the enquiry route. Whether a
  separate written processing agreement is needed for this engagement is a
  question for the solicitor review.
- The studio does not sell, share or use your data for marketing.

## 15. ⚖ Liability

Written plainly, and deliberately conservative about what it claims.

- The studio takes responsibility for its own work: if something delivered is
  wrong, it is put right (§11).
- **The studio's total liability under this engagement is limited to the fees
  paid.**
- The studio is not liable for loss of profit, loss of enquiries, loss of data,
  or loss of business reputation.
- The studio is not liable for the acts, pricing or failures of third-party
  services (§6), or for content you supply or insist on.
- Nothing here limits liability for death or personal injury caused by
  negligence, for fraud, or for anything else that cannot lawfully be limited.

**This clause has not been reviewed by a solicitor.** A liability cap that is
unreasonable is unenforceable, and "reasonable" depends on the contract and the
parties. The cap above is a starting position for that review, not a settled
term. Confirm the studio's professional-indemnity insurance is in force and that
its terms sit consistently with this clause.

| | |
| --- | --- |
| Professional indemnity insurer | |
| Cover level | |
| Renews | |

## 16. ⚖ Governing law and disputes

- This engagement is governed by the law of **England and Wales**, and the courts
  of England and Wales have exclusive jurisdiction.
- **Talk first.** If something goes wrong, raise it directly and in writing. Most
  disputes on work this size are a misunderstanding about scope, and the scope
  change log exists precisely so that it can be settled by looking something up.
- If a direct conversation does not resolve it within **[n] days**, both parties
  agree to try mediation before starting proceedings.
- Neither step prevents either party from seeking an urgent remedy from a court
  where one is genuinely needed.

**Confirm the jurisdiction before issuing** if the client is based outside
England and Wales, or trades through a company rather than as an individual.

## 17. Confirming

Reply in writing that you accept these terms, or sign below. The deposit invoice
follows, and the intake questionnaire is attached to this document — you can
start on it straight away.

If anything here reads as unfair or unclear, say so before you sign. A term you
did not understand is not a term that will be enforced comfortably by either of
us.

| | |
| --- | --- |
| Client name | |
| Signature | |
| Date | |
| Studio | Alexander Watson |
| Date | |

---

# Part B — Payment record

**Internal.** One block per client. Kept current, not reconstructed at year end.

| | |
| --- | --- |
| Agreed total | |
| Invoiced to date | |
| Received to date | |
| Outstanding | |

| # | Invoice no. | For | Amount | Issued | Due | Paid | Method | Reference |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | | Deposit | | | | | | |
| 2 | | Stage 05 approval | | | | | | |
| 3 | | Launch | | | | | | |

**Chases**

| Invoice | Chased | How | Response | Work paused? |
| --- | --- | --- | --- | --- |
| | | | | |

**Expenses recharged**

| Date | Item | Cost | On which invoice | Client approved in advance? |
| --- | --- | --- | --- | --- |
| | | | | |

---

# Part C — Scope change log

Anything agreed after signature that changes what is being made, what it costs,
or when it is delivered. A change that is not written here did not happen.

| # | Date | Change | Requested by | Effect on scope | Effect on fee | Effect on date | Client agreed (how) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |

> Three unlogged small favours cost more than one logged change. Log the small
> ones.

**Delay register.** Feeds §8 and the project's blocker list on the Studio Dashboard.

| # | Waiting on | Requested | Chased 1 | Chased 2 | Received | Days lost |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

---

# Part D — Engagement status

| | |
| --- | --- |
| Confirmation issued | |
| Signed / accepted in writing | |
| Deposit received | |
| Start date held | |
| Intake sent | |
| Eight launch facts closed | |
| Entered on the Studio Dashboard | |
| Approver named (§7) | |
| Response time agreed (§7) | |
| Dormancy threshold agreed (§8) | |
| Defects window ends | |
| Care agreed or declined | |

A project is on the **Studio Dashboard** from the day the enquiry arrives, not
the day the deposit clears. The dashboard is the live status — stage, next
action, blockers, contact history. `Registers/project-tracking.md` is its
human-readable seed and export record, not a second board.

**Before issuing, check:** every `[n]` and `[rate]` placeholder is filled, and
the ⚖ clauses have been through solicitor review — or, if they have not, that
you have decided knowingly to proceed and recorded that decision here.

| | |
| --- | --- |
| Solicitor review completed | |
| Reviewed by | |
| Clauses changed at review | |
| If issued without review — decision recorded by, and date | |
