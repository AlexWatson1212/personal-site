# Stage 06 — Website Build Pack

**Client:**
**Copy Approval version:** *(approved [date] — the words come from there, not from here)*
**Brand System Sheet version:** *(approved [date] — this pack may not exceed it)*

Everything needed to build without a further decision. If a decision is missing,
it goes in §9 rather than being guessed at.

**This pack does not decide anything the client has already approved.** The
sitemap and every visible word come from
`03b Copy Approval/02b-copy-approval.md`, which is authoritative and stays
authoritative through every later change. The visual system comes from the
approved Brand System Sheet. What this pack adds is the technical work of
building both.

---

## 1. Sitemap and page purposes

**Copied from the approved sitemap in `03b Copy Approval/02b-copy-approval.md`
§1.** It is reproduced here so the pack is buildable on its own, not re-decided.
If this table and the Copy Approval disagree, the Copy Approval is right.

| Section | Anchor | Purpose — one sentence | Primary action present? |
| --- | --- | --- | --- |
| Hero | `#home` | | |
| Recognition — "is this you?" | | | |
| Statement | | | |
| Approach — how I work | | | |
| Fit — who this is not for | | | |
| About | | | |
| Practical | | | |
| FAQs | | | |
| Contact | `#contact` | | |
| Crisis support | | | no |

**Why the crisis section is last and never carries the primary action.** Someone
in crisis should meet external routes, not an enquiry form with a stated reply
time of several days.

Header navigation is short enough that the bar never crowds — five items maximum.
The footer repeats the full journey including the entry point.

## 2. Final page copy

**The approved copy lives in `03b Copy Approval/02b-copy-approval.md` §2, and
that document is authoritative.** Copy is approved at Stage 03b, before the Brand
System Sheet is written — the design is set to real words, never to placeholder
text.

Reproduce the approved wording here for the build, and record any change back in
the Copy Approval's change table rather than editing it only here. A word that
exists in the build and not in the Copy Approval is a word nobody approved.

For each section:

```
### [Section name]            anchor: #
Eyebrow:
Heading:                      (a full sentence that carries meaning alone)
Lede:
Body:
Action label / destination:
Notes for build:
```

**Copy rules**

- One `<h1>`, in the hero.
- Headings are sentences, not labels. "Clarity before you commit to anything"
  beats "Practical information".
- Nothing states an outcome the client cannot evidence.
- Fee, availability, training wording and reply time appear exactly as confirmed
  in the Stage 03 practical table — never paraphrased.

## 3. SEO

Two halves, and confusing them is how a client ends up being asked to approve a
canonical tag.

**Client-approved — from `03b Copy Approval` §5.** These are the words a searcher
reads. They are not re-decided here.

| Field | Value | Limit |
| --- | --- | --- |
| Title | | ≤60 chars |
| Meta description | | ≤155 chars |

**Studio-controlled — implementation.** Technical correctness, decided here and
never sent for client approval. The client is told what was done at handover.

| Field | Value | Note |
| --- | --- | --- |
| OG title | | May differ from the page title; not client-approved |
| OG description | | |
| OG image | | 1200×630 |
| Canonical | | must match `robots.txt`, `sitemap.xml` and `CNAME` |
| Redirects | | apex ↔ `www`, and any old URLs |
| `sitemap.xml` implementation | | |
| `robots.txt` | | |

**Structured data:** `Person` or `LocalBusiness`/`MedicalBusiness` as appropriate,
including only confirmed credentials. No `aggregateRating`. No fabricated
`openingHours`.

**The canonical trap.** The canonical URL is set once in the site config and
flows into metadata, Open Graph and structured data. Three other files must
agree: `robots.txt`, `sitemap.xml`, `CNAME`. Decide apex or `www`, redirect the
other permanently, and make all four match. Split values point the canonical tag
somewhere the visitor is not.

## 4. Image list

| Filename | Slot | Master dimensions | Variants | Format | Alt text |
| --- | --- | --- | --- | --- | --- |
| | | | | WebP q76 | |

Masters are retained and are not what the page requests. Replacing photography
means regenerating variants from the master at the recorded widths and quality —
record them here or the next person guesses.

Prompts for non-photographic assets only, copied verbatim from the Brand System
Sheet §4.

## 5. Components

| Component | States | Notes |
| --- | --- | --- |
| Header + nav | default, scrolled, menu open | one `<nav>` serving both breakpoints |
| Mobile menu | open, closed | full-screen panel below the header bar; page scroll-locked; `visibility: hidden` when closed so links leave the tab order without JS `inert` |
| Hero | — | responsive `<picture>`/`srcset`, `sizes` accounting for the `object-fit: cover` crop factor |
| Full-bleed statement | light, dark | inverted focus ring on dark |
| Recognition list | — | |
| Card / item | — | |
| Definition list (practical) | — | |
| FAQ | collapsed, expanded | native `<details>` unless there is a reason not to |
| Enquiry form | idle, focus, invalid, submitting, sent, error | error shown as border **and** text |
| Footer | — | |
| Skip link | hidden, focused | |

No component outside this list without a flagged decision.

## 6. Brand tokens

Copied from the approved sheet into the token block, unaltered. Components
reference semantic names (`--surface`, `--text-secondary`, `--line`), never raw
hexes — a brand change should be a one-line edit, not a search across the file.

```css
:root {
  /* Colour — raw */
  /* Semantic roles */
  /* Type families, steps, leading, measures */
  /* Space — 8px base */
  /* Layout — shell, gutter, section rhythm, header */
  /* Form — radius, border, motion, ease */
}
```

## 7. Build and QA checklist

**Build**

- [ ] Token block written first, from the sheet, before any component
- [ ] No colour, font, weight or component absent from the sheet
- [ ] Semantic tokens used throughout; no raw hexes in component rules
- [ ] Responsive image variants generated; `sizes` verified against the crop
- [ ] No web font loaded unless the sheet says so
- [ ] No `backdrop-filter`, gradient, shadow-as-hierarchy or icon library

**QA — accessibility**

- [ ] Every text pairing measured, 4.5:1 body / 3:1 large
- [ ] Focus visible everywhere, inverted on dark sections
- [ ] One `<h1>`; no skipped heading levels
- [ ] Full keyboard pass, including the mobile menu
- [ ] 320×480 usable; no horizontal scroll at any width
- [ ] Form labels visible; errors not colour-alone
- [ ] `prefers-reduced-motion` honoured

**QA — content**

- [ ] Fee, training wording, registration, location, availability and reply time
      match the confirmed Stage 03 table exactly
- [ ] No membership or accreditation mark without confirmed permission
- [ ] Crisis section present, with working external links
- [ ] Every external link opens correctly and still exists

**QA — technical**

- [ ] Enquiry route tested on phone and desktop with the client's mail app
- [ ] Test message received at the real address
- [ ] Canonical, `robots.txt`, `sitemap.xml` and `CNAME` all agree
- [ ] Structured data validates
- [ ] Build artifact validates; server renders HTML

## 8. Cloudflare launch checklist

- [ ] Production deploys as a Cloudflare Worker via the hosting workflow
- [ ] Any competing deployment disabled — a stale GitHub Pages source will serve
      the repository README instead of the site
- [ ] Custom domain attached to the Worker deployment
- [ ] DNS records correct and proxied
- [ ] Apex ↔ `www` redirect rule live in the agreed direction
- [ ] HTTPS enforced; certificate valid
- [ ] Caching sane for a mostly-static site
- [ ] 404 behaviour checked
- [ ] Live site loaded on a phone on mobile data, not just on wifi
- [ ] Sitemap submitted in Search Console **after** the correct site is live
- [ ] Client sent the live URL, the enquiry test result and what to do if the
      form ever stops arriving

## 9. Decisions still open

| # | Decision | Options | Recommendation | Owner | Blocks launch? |
| --- | --- | --- | --- | --- | --- |
| | | | | | |
