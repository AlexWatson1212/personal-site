# Stage 03b — Copy Approval

**The authoritative record of the approved words.** Sitemap, every piece of
visible wording, headings, calls to action, factual placeholders, SEO titles and
meta descriptions, the client's approval, and every approved change after it.

Nothing visual is designed until this document is approved. The Brand System
Sheet is set to the copy that exists, not to copy that is imagined.

> **The file keeps its previous name.** It was `02b-copy-approval.md` under the
> old numbering, and older references point at that name. The folder carries the
> `03b` position so it sorts where it belongs — after Practice Clarity, before
> Visual Identity. Nothing else in the system was renumbered.

**Client:**
**Practice Clarity brief version:** *(approved [date] — every claim below traces
back to it)*

---

## Why this stage exists

Copy comes before visual identity because words are the harder problem and the
one the client can actually judge. A brand system built to placeholder text
looks finished and decides nothing; the first real sentence then breaks the
layout, the heading scale or the tone, and the sheet is reopened.

Approving the words first means the Brand System Sheet is designed to a known
quantity: real headings of real length, real calls to action, the actual
practical facts. It also gives the client something they can read and correct in
their own language, before they are asked to judge colour.

**The exit point.** A client may stop after the Practice Clarity brief with a
completed deliverable and nothing outstanding. Copy Approval is the first stage
of the website itself. Confirm the client is continuing before starting it.

---

## 1. Approved sitemap

Most therapist practices need one page, well sequenced, rather than six thin
ones. Default to a single page with anchored sections; move to multiple pages
only when there is a reason worth naming.

This table, once approved, is what the Build Pack builds. A section that is not
here does not get built, and a section here is not quietly dropped.

| # | Section or page | Anchor / URL | Purpose — one sentence | Primary action present? | Approved |
| --- | --- | --- | --- | --- | --- |
| 1 | Hero | `#home` | | | |
| 2 | Recognition — "is this you?" | | | | |
| 3 | Statement | | | | |
| 4 | Approach — how I work | | | | |
| 5 | Fit — who this is not for | | | | |
| 6 | About | | | | |
| 7 | Practical | | | | |
| 8 | FAQs | | | | |
| 9 | Contact | `#contact` | | | |
| 10 | Crisis support | | | **no** | |

**The crisis section is last and never carries the primary action.** Someone in
crisis should meet external routes, not an enquiry form with a stated reply time
of several days.

Header navigation is five items maximum. The footer repeats the full journey
including the entry point.

---

## 2. Page copy — the approved wording

One block per section, in sitemap order. This is the visible wording, final
rather than indicative. Every claim traces to something the client confirmed in
the Practice Clarity brief.

```
### [Section name]                    anchor: #
Eyebrow:
Heading:                              (a full sentence that carries meaning alone)
Lede:
Body:
Call to action — label:
Call to action — destination:
Notes for build:                      (never client-facing wording)
Approved:                             ☐  date:
```

**Copy rules**

- One `<h1>`, in the hero.
- Headings are sentences, not labels. "Clarity before you commit to anything"
  beats "Practical information".
- Nothing states an outcome the client cannot evidence.
- Fee, availability, training wording and reply time appear exactly as confirmed
  in the Practice Clarity practical table — never paraphrased.
- British English throughout.

---

## 3. Calls to action

One primary action, repeated. A page with three competing actions has none.

| Where | Label | Destination | Primary or secondary | Approved |
| --- | --- | --- | --- | --- |
| | | | | |

**What a good enquiry contains, and what happens after it is sent.** Written
here because it is the sentence under the form, and it is a promise:

>

---

## 4. Factual placeholders

The wording that cannot be invented, drafted or approximated. Each one is a
launch blocker until it is confirmed by the client in writing, and each one
appears on the page exactly as recorded here.

These are the same eight facts the engagement confirmation asks for at Stage 01
and the clarity call reads back at Stage 02. If they are still open here, they
are late.

| # | Fact | Approved public wording | Source | Confirmed by client | Date |
| --- | --- | --- | --- | --- | --- |
| 1 | Training — public wording | | Course / placement / insurer | | |
| 2 | Registration or membership — public wording | | Professional body | | |
| 3 | Location wording | | Client | | |
| 4 | Online sessions offered | | Client | | |
| 5 | Session fee, and whether it is public | | Client | | |
| 6 | Current availability | | Client | | |
| 7 | Stated reply time | | Client | | |
| 8 | Enquiry address | | Client | | |
| 9 | Privacy and data-retention statement | | Client | | |
| 10 | Safeguarding and crisis information | | Client | | |

**No logo, membership mark or credential goes on the page until both the wording
and the permission to use it are confirmed.**

---

## 5. SEO — what the client approves

The client approves the words a searcher reads. The studio implements the
machinery behind them.

**Client-approved.** These are visible in search results and are the client's
own description of their practice, so they are approved here alongside the page
copy.

| Page / section | Title (≤60 chars) | Meta description (≤155 chars) | Approved | Date |
| --- | --- | --- | --- | --- |
| | | | | |

**Studio-controlled — implementation, not wording.** Recorded here so it is
visible, decided in the Build Pack, and never sent to the client for approval:

- canonical tags
- Open Graph and social metadata
- structured data
- redirects
- sitemap implementation and `robots.txt`

These are technical correctness rather than editorial decisions. The client is
told what was done at handover; they are not asked to approve it.

**The canonical trap.** The canonical URL is set once and flows into metadata,
Open Graph and structured data. Three other files must agree: `robots.txt`,
`sitemap.xml`, `CNAME`. Decide apex or `www`, redirect the other permanently,
and make all four match. This is settled in the Build Pack, not here.

---

## 6. The client's approval

Copy is approved as a whole. Section-by-section approval leaves a page that
nobody has read end to end.

| | |
| --- | --- |
| Sent for approval on | |
| Sent to | |
| Approved on | |
| Approved by | *(the one named person from the engagement confirmation)* |
| Method | *(email, signed PDF, recorded call followed by written confirmation)* |
| Version approved | |

**What approval means, in the words used with the client:**

> Approving the copy means these are the words that will be built. The brand
> system is designed to fit them, so changing them afterwards changes the design
> as well. Read it as a whole rather than a section at a time, and tell me what
> is wrong rather than what is missing — I will find the gaps.

### Changes requested before approval

| # | Section | Requested | Response | In scope? | Actioned |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

---

## 7. Approved copy changes after approval

Every change to the words after the approval above. This table is the reason
this document is authoritative rather than a snapshot: the approved copy is what
is recorded here, as amended, not what was sent on the original date.

| # | Date | Section | From | To | Requested by | Round | Design impact | Approved |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | |

**Design impact** is the column that stops copy changes being treated as free.
A longer heading changes the type scale; a fourth call to action changes the
component set. Where a copy change moves something on the Brand System Sheet,
say so in that column and record it as a documented extension in
`05 Client Approval/05-approval-email-and-log.md`.

### How these rounds are counted

**Copy changes and visual changes share the website's two consolidated revision
rounds. They are not separate allowances.**

- A round is one collected response, not a stream of individual messages.
- A round may contain copy changes, visual changes, or both. It is still one
  round.
- Corrections of fact — a wrong fee, a misspelled name, wording a professional
  body requires — are not revisions and are not counted.
- Once both rounds are used, further changes are quoted before any work starts,
  at the rate in the engagement confirmation.

| Round | Date received | Copy changes | Visual changes | Used |
| --- | --- | --- | --- | --- |
| 1 | | | | ☐ |
| 2 | | | | ☐ |

---

## 8. Decisions still open

Anything not settled goes here rather than being guessed at. An open row is a
blocker on the Brand System Sheet, because the sheet is set to the copy.

| # | Open question | Blocks | Owner | Needed by | Closed |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

---

**Internal-only versus client-facing.** Sections 1 to 6 are client-facing once
completed — the sitemap, the wording, the calls to action, the facts, the titles
and descriptions, and the approval itself are all things the client reads and
signs off. Section 7's *Design impact* and round-counting columns and the whole
of section 8 are internal. Never send the round tally to a client mid-project;
tell them plainly when a round is being used, at the time.
