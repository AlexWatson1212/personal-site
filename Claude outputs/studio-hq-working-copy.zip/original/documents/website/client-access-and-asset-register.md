# Register — Client Access and Asset Register

**Client:**
**Project:**
**Opened:**
**Last verified:**

**Internal.** One register per client. It answers a single question at any point
in the project: *who controls what, and what has to move at handover.*

This is the register that prevents the two failures that outlive a project — a
site nobody can redeploy because the account is in the studio's name, and a
domain that lapses because nobody knew whose card was on it.

Opened at Stage 01, filled through the build, verified at Stage 07, and closed
when the retention period expires.

---

## The ownership principle

**Every account is in the client's name from the day it is created.** The studio
is added as a collaborator or delegate; the studio is never the sole owner and
never the registrant. Retrofitting ownership after launch is slow, error-prone,
and occasionally impossible.

Where this cannot be done — a platform with no delegate model, an account the
client cannot create themselves yet — it is recorded below as a **deviation**,
with the date it must be corrected by. A deviation that has no correction date
is a deviation that becomes permanent.

| # | Deviation | Why it was necessary | Correct by | Corrected |
| --- | --- | --- | --- | --- |
| | | | | |

---

## 1. Domain

| | |
| --- | --- |
| Domain | |
| Registrar | |
| Registrant name on the account | |
| Registrar account owned by | Client / Studio |
| Studio access | Delegate / none |
| Registered | |
| Expires | |
| Auto-renew on? | |
| Card on file belongs to | |
| Registrar lock on? | |
| Auth / EPP code held by | Client |
| Privacy protection on? | |
| Apex or `www` canonical | |

**The four values that must agree.** Canonical URL in the site config,
`robots.txt`, `sitemap.xml`, `CNAME`. Record the agreed direction here and the
date all four were checked together.

| Agreed canonical | Redirect direction | All four verified on |
| --- | --- | --- |
| | | |

## 2. DNS and hosting

| | |
| --- | --- |
| DNS provider | |
| Hosting platform | |
| Account owner | |
| Plan / tier | |
| Cost, and who pays | |
| Renews | |
| Studio access level | |
| Deployment method | |
| Custom domain attached to | |
| Competing deployments disabled? | |
| HTTPS enforced / certificate | |

## 3. Repository and build

| | |
| --- | --- |
| Repository host | |
| Repository URL | |
| Owner of the repository | |
| Studio access level | |
| Private or public | |
| Default branch | |
| Build command | |
| Node / runtime version | |
| Environment variables, and where they are stored | |
| Deploy secrets held by | |
| Where the master copy lives at handover | |

**No secret is ever committed.** Environment variables are recorded here by
*name and purpose only*, never by value.

| Variable name | Purpose | Required for build? | Value stored where |
| --- | --- | --- | --- |
| | | | |

## 4. Email and the enquiry route

| | |
| --- | --- |
| Public enquiry address | |
| Mailbox provider | |
| Account owner | |
| Is this a personal address? | |
| Form delivery mechanism | |
| Delivery service / API account owner | |
| Tested from phone and desktop on | |
| Test message received at the real address on | |
| Spam / deliverability checked | |
| What the client does if enquiries stop arriving | |

> A public enquiry address is a decision, not a leftover. If a personal address
> is going live, it is recorded here as a confirmed choice with a date, not as
> the thing that happened to be in the questionnaire.

## 5. Accounts and access

Every account the project touches. One row each, including the ones the studio
does not hold.

| Service | Purpose | Account in the name of | Login held by | Studio role | MFA on? | Shared how | Transfers at handover? | Verified |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | |

**Credential rules**

- Credentials are never sent by email, message or document — including this one.
- Sharing is by password-manager share or by the platform's own invitation flow.
- MFA is on for the domain registrar, the host and the repository without
  exception. Recovery codes sit with the client, not the studio.
- Every studio credential is revoked, and every shared password rotated, at
  handover. The date goes in §9.
- This register records *where a credential lives*. It never records the
  credential.

## 6. Assets held

| Asset | Format | Source | Master held where | Delivered to client? | Notes |
| --- | --- | --- | --- | --- | --- |
| Photography — masters | | Client / commissioned | | | Never delivered as web variants only |
| Photography — web variants | WebP | Generated from masters | | | Record widths and quality |
| Logo files | | | | | |
| Favicon / social share image | | | | | |
| Final copy — source of truth | | Stage 06 build pack | | | |
| Practice Clarity document | PDF | Studio | | | |
| Brand System Sheet | PDF | Studio | | | |
| Website Handover and Care Guide | PDF | Studio | | | |

**Masters are retained and are not what the page requests.** Replacing a
photograph means regenerating variants from the master at the recorded widths
and quality. If the widths are not written down, the next person guesses.

## 7. Fonts and licences

| Font / asset | Licence | Permits self-hosting? | Held by | Cost | Renews | Evidence of licence |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

Record the faces actually used on **this project**, with evidence of the licence.
A client system specifies its own faces, and whatever the approved Stage 04 Brand
System Sheet says governs the build.

**Do not copy the studio's typefaces into this table.** Newsreader and Instrument
Sans are the *studio's* identity (Brand and Digital Identity Guidelines §04).
They belong to studio output — documents, emails, the studio site — and they do
not travel onto a client's site. A client site using them would be a decision
made on their Stage 04 sheet for their own reasons, recorded here like any other.

**Self-hosting matters at handover.** A face that cannot be self-hosted cannot be
embedded in a delivered PDF and cannot be served from the client's own account.
Check the licence before the sheet is approved, not after.

**The studio wordmark never appears in this table**, because it never appears on
a client's site. It is supplied vector artwork, it is not licensed to clients,
and it is not to be recreated by typing the name in a font.

## 8. Third-party services and recurring costs

| Service | Purpose | Account owner | Cost | Billing to | Renews | Cancel by | What breaks if it lapses |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |

Anything in this table with a renewal date goes into the care-stage renewal
calendar in `07 Handover and Care/07-website-handover-and-care-guide.md`.

## 9. Personal data held by the studio

Recorded so that it can be deleted, and so that the client can be told what is
held if they ask.

| What is held | Where | Lawful basis / reason | Retention period | Delete by | Deleted |
| --- | --- | --- | --- | --- | --- |
| Returned intake questionnaire | | Delivery of the engagement | | | |
| Clarity call notes | | | | | |
| Correspondence | | | | | |
| Invoices and payment records | | Statutory retention | | | |
| Photography masters | | | | | |

No material about the client's own clients is held, ever. If something
identifying arrives in a questionnaire answer or a call note, it is removed at
the point it is noticed and the removal is logged below.

| Date | What was removed | Where from | Confirmed |
| --- | --- | --- | --- |
| | | | |

## 10. Handover transfer checklist

Completed at Stage 07, before final sign-off. Every line needs a date, not a
tick.

- [ ] Domain registrant, account and payment card confirmed in the client's name
- [ ] Registrar MFA on; recovery codes with the client
- [ ] Hosting account in the client's name; studio holds delegate access only
- [ ] Repository transferred to the client's account, or a full copy delivered
      and its location recorded above
- [ ] Environment variables and deploy secrets in the client's account
- [ ] Enquiry route tested from the client's own device after transfer
- [ ] Photography masters delivered, with the variant widths and quality recorded
- [ ] Final copy source delivered
- [ ] Practice Clarity, Brand System Sheet and Handover Guide issued as PDFs
- [ ] Every shared password rotated
- [ ] Every studio credential the client does not need revoked
- [ ] Studio access retained only where the care arrangement requires it —
      listed explicitly below
- [ ] Client shown where each account lives and how to reach it without the studio
- [ ] Register re-verified end to end and dated

**Studio access retained after handover, and why**

| Service | Access level | Reason | Review on |
| --- | --- | --- | --- |
| | | | |

If the care arrangement ends, everything in this table is revoked within seven
days. Retained access with no live reason is the thing that turns into an
awkward email in two years.

## 11. Verification log

The register is only worth what its last verification date says.

| Date | Verified by | What changed | Anything found wrong |
| --- | --- | --- | --- |
| | | | |

Verify at: Stage 05 approval, first deploy, launch, handover, then at each care
review.
