# Stage 04 — Brand System Sheet

**Client:**
**Version:**
**Approved:**

**Copy Approval version this sheet was designed to:** *(approved [date])*

This sheet is the source of truth for every later stage. If a value is not on
this sheet, it does not appear in the build. See `Worked Example/` for a completed one.

**Do not start this sheet until the website copy is approved.** Stage 03b closes
first. The type scale, the heading treatment, the component set and the measure
are all set to the words that exist — real headings of real length, the actual
calls to action, the confirmed practical facts. A sheet designed to placeholder
text looks finished and decides nothing, and the first real sentence reopens it.

If the approved copy changes afterwards, record the design impact in the Copy
Approval's change table and, where it moves something here, as a documented
extension in `05 Client Approval/05-approval-email-and-log.md`.

---

## 1. Colour — 5 to 7, each with a role

Every colour earns a named role. A colour without a role is decoration, and
decoration is what makes small sites look uncertain.

| Name | Hex | Role | Permitted use | Never |
| --- | --- | --- | --- | --- |
| | | Level 1 — primary surface | | |
| | | Level 2 — raised panels | | |
| | | Level 3 — contrast sections, primary button | | |
| | | Text / deepest section | | |
| | | Borders, dividers, quiet surfaces | | |
| | | Accent — rules and quiet emphasis | | |
| | | Supporting neutral — secondary text | | |

**Proportion:** roughly 70% surface, 20% contrast, 10% quiet. Stated so that a
later page cannot drift into being mostly accent.

**Contrast, measured not assumed.** Record the real ratio for every text pairing.
Any colour below 4.5:1 on its background is barred from body text and given a
non-text role instead — say so here rather than leaving it to be discovered.

| Foreground | Background | Ratio | Verdict |
| --- | --- | --- | --- |
| | | | |

**Documented extensions.** Colours outside the core palette, if any. Each needs a
reason, exactly one permitted location, and a measured ratio.

| Hex | Reason it exists | Permitted in | Ratio |
| --- | --- | --- | --- |
| | | | |

## 2. Typography

| Role | Family | Fallback stack | Size | Leading |
| --- | --- | --- | --- | --- |
| Display | | | | |
| Statement | | | | |
| Section | | | | |
| Item | | | | |
| Lede | | | | |
| Body | | | | |
| Detail | | | | |
| Label | | | | |

**Steps are deliberate.** Each step must be clearly dominant over the next. Five
near-equal sizes read as a mistake; four separated ones read as a system.

**Measure, not width caps.** Reading copy sits at 55–70 characters per line, set
in `ch`. Do not cap individual headings in `ch` — per-heading caps are what break
composition across breakpoints. Use one or two shared measures plus
`text-wrap: balance` on headings and `text-wrap: pretty` on prose.

**Web font decision:** loaded / not loaded — and the consequence, stated.
Not loading costs nothing and cannot cause a flash of unstyled text, but the
identity then varies by platform. Record which was chosen and why.

## 3. Space, borders, buttons, forms

| | |
| --- | --- |
| Base unit | 8px |
| Scale | 2xs 8 · xs 16 · sm 24 · md 32 · lg 48 · xl 64 |
| Shell max width | |
| Gutter | |
| Section rhythm | |
| Radius | Containers only. Structural elements 0. Nothing fully rounded. |
| Border weight | |
| Motion | duration + easing, and nothing animates on scroll |

**Buttons**

| | |
| --- | --- |
| Minimum height | 3rem — a genuine touch target |
| Primary | fill + border, inverts on dark surfaces rather than disappearing |
| Hover | colour change only; no lift, no shadow, no scale |
| Text links | underlined with offset; no arrows drawn as images |

**Forms**

| | |
| --- | --- |
| Input min-height | 3rem |
| Textarea min-height | ~9.5rem, vertical resize only |
| Label | above the field, always visible — never a placeholder standing in |
| Focus | 2px solid outline in the focus colour, no offset on fields |
| Error | border colour change + text; never colour alone |
| Required marks | worded, not asterisked |

## 4. Image direction

**Principle:** real photography of the practitioner, or nothing. No stock, no
generated therapy imagery, no simulated sessions, no hands-on-shoulders.

| Slot | Ratio | Widths to generate | Format | Alt text |
| --- | --- | --- | --- | --- |
| Hero | | | WebP q76 | |
| Portrait | | | WebP q76 | |
| Social share | 1200×630 | — | WebP <250KB | n/a |

**Image-generation prompt** — used only for non-photographic assets such as the
social card or icon, never for imagery implying a real setting:

> *[Precise prompt here. State the palette hexes, the composition, the negative
> space, and an explicit exclusion list: no gradients, no stock elements, no
> simulated therapy scene, no alteration of the subject's face.]*

## 5. Voice

| | |
| --- | --- |
| Register | |
| Sentence length | |
| Person | second person to the reader; first person for the practitioner |
| Claims | only what the client can evidence |
| Banned phrases | |

## 6. Accessibility

- Body text at 4.5:1 minimum, large text at 3:1, verified per pairing above.
- Visible focus on every interactive element, inverted on dark sections.
- One `<h1>`; heading levels never skipped.
- Skip link to main content.
- Mobile menu usable at 320×480, scroll-locked behind, hidden from the tab order
  when closed.
- Never colour alone to carry meaning.
- `prefers-reduced-motion` honoured.
- Target size 44px minimum.

## 7. Avoid — explicit

- Glassmorphism and `backdrop-filter` blur
- Drop shadows used as hierarchy
- Gradients
- Icon libraries and decorative iconography
- Scroll-triggered animation and parallax
- Ghosted oversized letterforms behind sections
- Decorative hairlines that frame nothing
- Full-round pills and heavy radii
- Stock photography of any kind
- A third near-white
- Counters, badges, testimonial carousels, urgency devices
- Any colour, weight or component not written on this sheet

---

**Approval:** Name — Date —
