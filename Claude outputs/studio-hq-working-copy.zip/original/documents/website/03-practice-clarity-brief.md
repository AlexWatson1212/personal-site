# Stage 03 — Practice Clarity brief

**Client:**
**Prepared:**
**Sources:** questionnaire returned [date], clarity call [date]

One to two pages. This is the document the client reads and says "yes, that is
what I meant" — or corrects. Everything after it is built on these words.

Write in the client's own register where possible. Where a phrase is theirs,
mark it. Do not smooth their language into industry copy.

> **This is an exit point.** A client may stop here with a completed Practice
> Clarity deliverable and nothing outstanding. Confirm in writing that they are
> continuing before Stage 03b begins.
>
> **What comes next is words, not pictures.** The next stage is
> `02b-copy-approval.md` — the sitemap and every piece of visible wording,
> approved by the client. The Brand System Sheet at Stage 04 is designed to that
> approved copy and is not started before it.

---

## 1. Who they help

Two or three sentences. Concrete enough that a reader either recognises
themselves or does not.

Avoid: "individuals experiencing a range of difficulties". Prefer the specific
population the client actually sees.

> *[Draft here]*

## 2. What clients are struggling with before therapy

The state of someone's life in the weeks before they make contact. Not
diagnoses — circumstances, and the private thought that finally makes them act.

> *[Draft here]*

## 3. What changes through the work

Written honestly, at the size it is actually true. Small and credible beats
large and unprovable. If the client cannot evidence it, it does not go in.

> *[Draft here]*

## 4. Practice approach, values and boundaries

| | |
| --- | --- |
| Modality and training | |
| What actually happens in session one | |
| What this practitioner does differently | |
| Explicit boundaries (hours, contact, cancellation, scope) | |
| Who this is not for | |
| Crisis position | |

## 5. Tone

| Feels like them | Does not |
| --- | --- |
| | |

**Words to use:**
**Words never to use:**

Sources they pointed to, and the reason each one works:

## 6. Desired action

One primary action. Everything else on the site is secondary to it.

| | |
| --- | --- |
| Primary action | |
| Where it appears | |
| What a good enquiry contains | |
| Stated reply time | |
| What happens after someone sends it | |

## 7. Practical requirements

| Item | Confirmed value | Status |
| --- | --- | --- |
| Public wording — training | | |
| Public wording — registration or membership | | |
| Location wording | | |
| Online sessions offered | | |
| Fee, and whether public | | |
| Enquiry address | | |
| Reply time | | |
| Domain, and where registered | | |
| Required privacy / data retention / safeguarding statements | | |

Nothing in this table may be inferred. Unconfirmed stays unconfirmed and blocks
launch.

## 8. Risks

| Risk | Likelihood | What we do about it |
| --- | --- | --- |
| Overclaimed outcome language | | Every claim traced to something the client can evidence |
| Scope creep beyond confirmed credentials | | No memberships or logos until wording is confirmed in writing |
| Crisis contact through the enquiry route | | Standing crisis statement and external routes, above the form |
| Client visibility discomfort | | Agree in advance what is public and what is not |
| | | |

## 9. Open questions

| # | Question | Owner | Needed by |
| --- | --- | --- | --- |
| | | | |

---

**Client sign-off:** this brief describes my practice accurately.
Name — Date —
