# Stage 07 — Website Handover and Care Guide

**Client:**
**Site:**
**Launched:**
**Version:**

The last document of the engagement and the first document of the relationship
that follows it. Part A is given to the client at launch. Parts B and C are
internal.

Handover is not "sending the link". It is the point at which the client can run
the site without the studio, and knows it.

**Set using:** `Brand and Document System/Master Templates v1.0.pdf` — the
*Website handover* application, 16:9. Language follows Section 09, Voice, of the
Brand and Digital Identity Guidelines.
**Depends on:** `Registers/client-access-and-asset-register.md` §10 completed
and dated. Handover does not happen before that checklist does.

---

# Part A — Your handover guide

**Client-facing.** Issued as a PDF at launch.

## 1. Your site is live

| | |
| --- | --- |
| Live address | |
| Launched on | |
| Enquiries arrive at | |
| Stated reply time on the site | |
| Where the site is hosted | |
| Where the domain is registered | |

## 2. What you now own

Everything below is in your name. Not licensed to you, not held on your behalf —
yours.

- The domain, registered to you, on your own registrar account
- The hosting account, in your name
- The site files and the copy
- Your photography, including the original full-size files
- Your Practice Clarity document and your Brand System Sheet
- This guide

The studio keeps access only where you have asked for it under a care
arrangement, and only to the services listed in §10. If the care arrangement
ends, that access is removed within seven days.

## 3. How your enquiries reach you

Someone fills in the form → the message is delivered to **[address]** → you
reply within the time your site states.

**Check it once a month. It takes two minutes.**

1. Open the site on your phone.
2. Send yourself a short test enquiry.
3. Confirm it arrives — and check the spam folder if it does not appear.

**If a test message does not arrive**

1. Check spam and any filters or rules on that mailbox.
2. Confirm the mailbox itself is working — send an ordinary email to it.
3. Check the delivery service is still active and has not hit a limit or lapsed
   on payment (§7).
4. If none of those explain it, contact me. Include the date and time of the
   test you sent, and the browser and device you sent it from.

**Do not assume silence means no enquiries.** A form that has quietly stopped
looks exactly like a quiet month.

## 4. What you can change yourself, and what to ask me about

**Change yourself, freely**

- Your reply time, availability and opening details — as long as what is on the
  site stays true
- Text corrections and additions within existing sections
- Adding a question and answer to the FAQs
- Replacing a photograph with another that follows the image direction in your
  Brand System Sheet

**Ask me before changing**

- Your fee, if it is shown publicly — the wording appears in more than one place
- Your training or registration wording — this must match exactly what your
  course, placement, insurer or professional body permits
- Adding a professional body logo or membership mark
- Adding a new page or section
- Anything involving colour, typeface, spacing or a new component

**Never, without a conversation**

- Anything not on your approved Brand System Sheet. That sheet is the reason the
  site holds together. One documented addition with a stated reason is a
  decision; three undocumented ones are drift, and drift is what makes a
  considered site start to look like a template.

## 5. Keeping the site honest

Some things on your site are facts, not copy, and they carry professional risk
if they drift out of date. Tell me — or update them — as soon as any of these
change:

| Fact on your site | Currently reads | Tell me if this changes |
| --- | --- | --- |
| Training and career-stage wording | | ✓ |
| Professional body registration or membership | | ✓ |
| Location, and whether it is current or intended | | ✓ |
| Session format — in person, online, both | | ✓ |
| Fee | | ✓ |
| Availability | | ✓ |
| Reply time | | ✓ |
| Crisis and support signposting | | ✓ — check the external links still work |
| Privacy, data-retention and safeguarding statements | | ✓ |

**Check the crisis links twice a year.** External services change numbers and
move pages. A crisis section with a dead link is worse than no crisis section.

## 6. What the site is built to do

So you know what standard to hold it to, and what to tell me if it slips.

- Readable at a genuine contrast level throughout — body text at 4.5:1 minimum
- Usable by keyboard alone, with a visible focus indicator on every link,
  button and field
- Usable on a small phone, with no sideways scrolling
- Form labels always visible; errors shown in words, not colour alone
- Animation respects your visitor's reduced-motion setting
- No stock photography, no urgency devices, no pop-ups, no autoplay
- One clear action per section

## 7. Renewals — the things that cost money and can lapse

| Item | Renews | Approximate cost | Whose card | What happens if it lapses |
| --- | --- | --- | --- | --- |
| Domain | | | | The site becomes unreachable, and the name can be bought by someone else |
| Hosting | | | | The site goes offline |
| Email | | | | Enquiries stop arriving |
| | | | | |

**Turn auto-renew on for the domain, and check the card on the account is one
you still use.** A lapsed domain is the one failure in this list that is not
always reversible.

## 8. Your documents

| Document | What it is for | When to open it |
| --- | --- | --- |
| Practice Clarity | Defines your practice, the people you work with, how the work is delivered, and how it should be described | Before writing anything public — a new page, a directory profile, a leaflet |
| Brand System Sheet | The colour, typography, spacing, image direction and voice rules your site is built from | Before changing anything visual, or briefing anyone else who makes something for you |
| This guide | How the site runs and who holds what | When something changes or something stops working |

Together these mean the next person who makes something for you — a directory
listing, a leaflet, a second website — has a specification to follow rather than
a guess to make.

## 9. The first thirty days

For **30 days** from launch, anything that does not work as specified is fixed
free of charge — a broken link, a form that fails to deliver, a layout that
breaks on a supported browser, a value that does not match what you confirmed.

Not covered: a change of mind, a new requirement, new content, a fact that has
changed since you confirmed it, or a fault in a third-party service. Those are
care work or quoted work.

The full terms, including which browsers and devices are supported, are §10 and
§11 of your engagement confirmation.

| | |
| --- | --- |
| Window ends | |
| Items raised | |
| Items fixed | |

## 10. Care

| | |
| --- | --- |
| Arrangement | |
| Fee, and how it is billed | |
| Review cadence | |
| How to reach me | |
| Response time for a normal request | |
| Response time if the site is down or the form has stopped | |
| Studio access retained, and to what | |
| Notice period, either side | |

**Included**

- [ ]
- [ ]

**Charged, at [rate]**

- [ ]
- [ ]

> Care exists so that support has a defined size. Without one it becomes unpaid
> and unreliable, which serves neither of us.

## 11. If you ever move on

Your site is yours and it can leave with you. If you want to work with someone
else, ask and you will receive: the repository or a complete copy of the site
files, your photography masters, your documents, and confirmation in writing
that every studio credential has been revoked. There is no fee and no notice
period for this.

---

**Handover accepted**

| | |
| --- | --- |
| Client name | |
| Signature | |
| Date | |
| Studio | Alexander Watson |
| Date | |

---

# Part B — Internal launch and handover record

## Launch record

| | |
| --- | --- |
| Final QA passed | |
| Deployed on | |
| Custom domain attached | |
| Competing deployments disabled | |
| Canonical, `robots.txt`, `sitemap.xml`, `CNAME` verified together | |
| Structured data validated | |
| Enquiry route tested — phone | |
| Enquiry route tested — desktop | |
| Test message received at the real address | |
| Live site loaded on mobile data, not wifi | |
| Sitemap submitted after the correct site was live | |
| Final invoice paid | |

## Handover checklist

- [ ] `Registers/client-access-and-asset-register.md` §10 complete and dated
- [ ] Every account confirmed in the client's name
- [ ] Studio credentials revoked except those listed in Part A §10
- [ ] Shared passwords rotated
- [ ] Photography masters delivered, with variant widths and quality recorded
- [ ] Repository transferred or a full copy delivered
- [ ] Practice Clarity, Brand System Sheet and this guide issued as PDFs
- [ ] Handover walkthrough held — the client sends a test enquiry themselves,
      from their own device, while we are both on the call
- [ ] Care arrangement agreed in writing, or explicitly declined
- [ ] Renewal calendar below populated
- [ ] Project register moved to Care

**The walkthrough matters more than the document.** A client who has sent one
test enquiry themselves will do it again. A client who has only been told how to
is relying on the studio.

## Documented extensions carried into the live build

Copied forward from `05 Client Approval/05-approval-email-and-log.md` so the
sheet, the build and the handover all agree.

| Extension | Reason | Permitted location | Measured ratio | On the sheet? | Client told? |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## Known compromises at launch

Anything shipped as good enough, so that it is a decision on a page rather than
a surprise later.

| # | Compromise | Why | Revisit by | Resolved |
| --- | --- | --- | --- | --- |
| | | | | |

---

# Part C — Care record

## Renewal calendar

| Item | Renews | Whose account | Reminder set | Last confirmed |
| --- | --- | --- | --- | --- |
| Domain | | | | |
| Hosting | | | | |
| Email | | | | |
| | | | | |

## Care log

| Date | Request | Type | Included or charged | Done | Invoiced |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

Types: content · factual correction · fix · accessibility · security · request
outside scope.

## Review

Held at the agreed cadence. Six questions, and they are the same every time.

1. Do the facts on the site still match the practice — fee, availability,
   training wording, registration, location, reply time?
2. Is the enquiry route still working, tested this month?
3. Do the crisis and support links still resolve to live services?
4. Has anything been added that is not on the Brand System Sheet?
5. Are all renewals current, on the right account and the right card?
6. Is the care arrangement still the right size for what is actually being
   asked for?

| Review date | Findings | Actions | Owner | Closed |
| --- | --- | --- | --- | --- |
| | | | | |

## Ending the arrangement

| | |
| --- | --- |
| Notice given by | |
| Date | |
| Reason | |
| Access revoked on | |
| Files and masters delivered on | |
| Client confirmed receipt | |
| Register closed | |
