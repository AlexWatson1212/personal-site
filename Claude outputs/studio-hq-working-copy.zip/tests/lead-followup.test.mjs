import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { serve, browser, open, stateWith, stored, daysBefore } from "./helpers.mjs";

const ROOT = path.resolve(process.env.SITE || "site");
const TODAY = "2026-09-26";
let srv, b;
before(async () => { srv = await serve(ROOT); b = await browser(); });
after(async () => { await b.close(); srv.server.close(); });

const lead = (o) => Object.assign({ id: "p1", name: "Sam Lead", role: "", warmth: "new", stage: "enquiry", source: "Instagram", need: "A first website", lastContact: daysBefore(TODAY, 8), waiting: "them", next: "Wait for their reply", followUp: "", followedUp: "", notes: "" }, o);
const homeText = (page) => page.locator("#main").innerText();

test("a quiet lead waiting on them surfaces one follow up on Home", async () => {
  const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([lead()]) });
  const t = await homeText(page);
  assert.match(t, /Follow up once with Sam Lead/);
  assert.match(t, /Quiet since/);
  assert.equal(await page.locator("[data-action=followed-up]").count(), 1);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("recording the follow up stops all further chasing, even weeks later", async () => {
  const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([lead()]) });
  await page.click("[data-action=followed-up]");
  assert.doesNotMatch(await homeText(page), /Follow up (once )?with Sam Lead/);
  const s = await stored(page);
  const p = s.people[0];
  assert.equal(p.followedUp, TODAY);
  assert.equal(p.lastContact, TODAY);
  assert.equal(p.waiting, "them");
  assert.equal(p.followUp, "");
  assert.equal(p.next, "");
  assert.match(p.notes, /Followed up once/);
  await ctx.close();
  // The same record, 60 days on: still nothing to chase.
  const later = await open(b, srv.url, { today: "2026-11-25", state: s });
  assert.doesNotMatch(await homeText(later.page), /Follow up (once )?with Sam Lead/);
  await later.page.goto(srv.url + "#/marketing/people");
  await later.page.waitForSelector("#rec-p1");
  const card = await later.page.locator("#rec-p1").innerText();
  assert.match(card, /Followed up once/);
  assert.match(card, /Nothing more to send unless they reply/);
  assert.doesNotMatch(card, /Follow up due/);
  assert.equal(await later.page.locator("#rec-p1 [data-action=followed-up]").count(), 0);
  assert.deepEqual([...errors, ...later.errors], []);
  await later.ctx.close();
});

test("exactly seven days of quiet is due; six is not", async () => {
  for (const [days, due] of [[7, true], [6, false]]) {
    const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([lead({ lastContact: daysBefore(TODAY, days) })]) });
    assert.equal(/Follow up once with Sam Lead/.test(await homeText(page)), due, `${days} days`);
    await ctx.close();
  }
});

test("no follow up is surfaced when it should not be", async () => {
  const cases = {
    "waiting on me": lead({ waiting: "me" }),
    "nobody waiting": lead({ waiting: "nobody" }),
    "waiting not recorded (older records)": lead({ waiting: undefined }),
    "already followed up": lead({ followedUp: daysBefore(TODAY, 3) }),
    "won": lead({ stage: "founding-client" }),
    "not now": lead({ stage: "not-now" }),
    "lost / closed": lead({ stage: "closed" }),
    "not a lead (person to know)": lead({ stage: "person-to-know" }),
    "not a lead (conversation, never enquired)": lead({ stage: "conversation" }),
    "no last contact date": lead({ lastContact: "" }),
  };
  for (const [name, p] of Object.entries(cases)) {
    const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([p]) });
    assert.doesNotMatch(await homeText(page), /Follow up (once )?with Sam Lead/, name);
    assert.deepEqual(errors, [], name);
    await ctx.close();
  }
});

test("a lead that enquired earlier stays a lead in any stage", async () => {
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([lead({ stage: "conversation", enquired: "2026-09-01" })]) });
  assert.match(await homeText(page), /Follow up once with Sam Lead/);
  await ctx.close();
});

test("manual follow-up dates keep working as before, without the lead button for non-leads", async () => {
  const p = lead({ stage: "person-to-know", waiting: "", followUp: TODAY, next: "Ask what she thought" });
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([p]) });
  const t = await homeText(page);
  assert.match(t, /Follow up with Sam Lead/);
  assert.match(t, /Ask what she thought/);
  assert.equal(await page.locator("[data-action=followed-up]").count(), 0);
  await ctx.close();
});

test("People: the Follow up due and Leads filters use the same rule", async () => {
  const people = [lead(), lead({ id: "p2", name: "Done Already", followedUp: daysBefore(TODAY, 2) }), lead({ id: "p3", name: "Just A Contact", stage: "person-to-know" })];
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith(people), hash: "#/marketing/people" });
  await page.click("[data-action=mfilter][data-id=due]");
  let t = await page.locator("#main").innerText();
  assert.match(t, /Sam Lead/); assert.doesNotMatch(t, /Done Already/); assert.doesNotMatch(t, /Just A Contact/);
  await page.click("[data-action=mfilter][data-id=leads]");
  t = await page.locator("#main").innerText();
  assert.match(t, /Sam Lead/); assert.match(t, /Done Already/); assert.doesNotMatch(t, /Just A Contact/);
  await ctx.close();
});

test("adding a lead through the form records source, need, enquiry date and quote date", async () => {
  const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([]), hash: "#/marketing/people" });
  await page.click("[data-action=add][data-kind=people]");
  await page.fill("#f-name", "Riya Referral");
  await page.selectOption("#f-stage", "proposal");
  await page.selectOption("#f-source", "Referral");
  await page.fill("#f-need", "Rewrite of an existing site");
  await page.fill("#f-lastContact", "2026-09-20");
  await page.selectOption("#f-waiting", "them");
  await page.fill("#f-quote", "995");
  await page.click("#dlg button[type=submit]");
  const p = (await stored(page)).people[0];
  assert.equal(p.source, "Referral");
  assert.equal(p.need, "Rewrite of an existing site");
  assert.equal(p.enquired, TODAY);
  assert.equal(p.quote, 995);
  assert.equal(p.quoteDate, TODAY);
  const card = await page.locator(`#rec-${p.id}`).innerText();
  assert.match(card, /Quote sent/); assert.match(card, /From Referral/); assert.match(card, /Quoted £995/); assert.match(card, /Needs: Rewrite/);
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("logging a contact records who is waiting, which drives the rule", async () => {
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([lead({ waiting: "me", lastContact: daysBefore(TODAY, 20) })]), hash: "#/marketing/people" });
  await page.click("#rec-p1 [data-action=log-contact]");
  assert.equal(await page.inputValue("#f-waiting"), "them"); // default after I have been in touch
  await page.fill("#f-lastContact", daysBefore(TODAY, 10));
  await page.fill("#f-what", "Sent the quote");
  await page.click("#dlg button[type=submit]");
  const p = (await stored(page)).people[0];
  assert.equal(p.waiting, "them");
  await page.goto(srv.url + "#/home");
  assert.match(await homeText(page), /Follow up once with Sam Lead/);
  await ctx.close();
});

test("Evidence shows enquiries, quotes, won, lost, values and sources", async () => {
  const people = [
    lead({ id: "a", stage: "enquiry", source: "Instagram" }),
    lead({ id: "b", stage: "proposal", source: "Referral", quote: 995, quoteDate: "2026-09-10" }),
    lead({ id: "c", stage: "founding-client", source: "Referral", quote: 495, quoteDate: "2026-09-01" }),
    lead({ id: "d", stage: "closed", source: "College", enquired: "2026-08-01", quote: 495 }),
    lead({ id: "e", stage: "not-now", source: "", enquired: "2026-08-02" }),
    lead({ id: "f", stage: "person-to-know", source: "Email" }), // not a lead: excluded
    lead({ id: "g", stage: "closed", source: "Email" }),          // closed contact who never enquired: excluded
  ];
  const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith(people), hash: "#/evidence" });
  const t = await page.locator("#le-h").locator("..").innerText();
  const row = (label) => t.split("\n").map((s) => s.trim()).reduce((v, s, i, a) => (s === label ? a[i + 1] : v), null);
  assert.equal(row("Enquiries"), "5");
  assert.match(row("Quotes sent"), /^3 £1,985 quoted in total$/);
  assert.match(row("Won"), /^1 £495$/);
  assert.equal(row("Lost"), "1");
  assert.equal(row("Not now"), "1");
  assert.equal(row("Still open"), "2");
  assert.equal(row("Sources"), "Referral 2, College 1, Instagram 1, Not recorded 1");
  assert.deepEqual(errors, []);
  await ctx.close();
});

test("Evidence with no leads says so plainly", async () => {
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([]), hash: "#/evidence" });
  assert.match(await page.locator("#le-h").locator("..").innerText(), /No leads recorded yet/);
  await ctx.close();
});

test("the lead rules now say one follow up, not two", async () => {
  const { page, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([]), hash: "#/clients/rules" });
  const t = await page.locator("#main").innerText();
  assert.match(t, /Stop after the one follow up/);
  assert.match(t, /After one follow up, stop/);
  assert.doesNotMatch(t, /second follow up can|A second can be used|After two follow ups|Stop after the second follow up|Chase a third time/i);
  await ctx.close();
});

test("records from before this change load and render without errors", async () => {
  const old = { id: "o1", name: "Old Record", role: "Therapist", warmth: "known", stage: "proposal", lastContact: "2026-08-01", next: "Chase", followUp: "", notes: "" };
  for (const hash of ["#/home", "#/marketing/people", "#/evidence"]) {
    const { page, errors, ctx } = await open(b, srv.url, { today: TODAY, state: stateWith([old]), hash });
    assert.deepEqual(errors, [], hash);
    if (hash === "#/home") assert.doesNotMatch(await homeText(page), /Follow up (once )?with Old Record/);
    await ctx.close();
  }
});
