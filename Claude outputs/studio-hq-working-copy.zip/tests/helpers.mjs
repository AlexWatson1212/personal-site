import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { chromium } from "playwright";

const TYPES = { ".html": "text/html; charset=utf-8", ".md": "text/plain; charset=utf-8", ".js": "text/javascript" };

export function serve(root) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
      if (p.endsWith("/")) p += "index.html";
      const file = path.join(root, p);
      if (!file.startsWith(root) || !fs.existsSync(file)) { res.writeHead(404); res.end("not found"); return; }
      res.writeHead(200, { "content-type": TYPES[path.extname(file)] || "application/octet-stream" });
      fs.createReadStream(file).pipe(res);
    });
    server.listen(0, "127.0.0.1", () => resolve({ server, url: `http://127.0.0.1:${server.address().port}/` }));
  });
}

export async function browser() {
  return chromium.launch({ args: ["--no-sandbox"] });
}

export const KEY = "aw-studio-hq.v1";

/** A minimal stored state; normalise() fills every other field with defaults. */
export function stateWith(people, extra = {}) {
  return Object.assign({ v: 1, settings: {}, people, migrated: { fos: "x", mkt: "x", studio: "x" } }, extra);
}

/** Open the app at `hash` with a fixed clock and a stored state. Returns { page, errors }. */
export async function open(b, url, { today = "2026-09-26", state = null, hash = "#/home", viewport = { width: 1280, height: 900 } } = {}) {
  const ctx = await b.newContext({ viewport });
  const page = await ctx.newPage();
  const errors = [];
  page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  page.on("pageerror", (e) => errors.push(e.message));
  await page.clock.setFixedTime(new Date(today + "T10:00:00"));
  if (state) await page.addInitScript(([k, v]) => { if (!sessionStorage.getItem("seeded")) { localStorage.setItem(k, v); sessionStorage.setItem("seeded", "1"); } }, [KEY, JSON.stringify(state)]);
  await page.goto(url + hash);
  await page.waitForSelector("#main h1");
  return { page, errors, ctx };
}

export async function stored(page) {
  return page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY);
}

export function daysBefore(iso, n) {
  const [y, m, d] = iso.split("-").map(Number);
  const t = new Date(y, m - 1, d - n);
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
}
