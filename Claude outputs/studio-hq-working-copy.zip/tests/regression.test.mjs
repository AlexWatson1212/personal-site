/* Renders every route in the original deploy and in this build with the same data
   and clock, and checks that only the intended pages changed, with no console errors. */
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import { serve, browser, open, stateWith } from "./helpers.mjs";

const NEW = path.resolve(process.env.SITE || "site"), OLD = path.resolve(process.env.BASELINE || "original");
const ROUTES = ["#/home", "#/studio", "#/marketing/plan", "#/marketing/people", "#/marketing/content", "#/marketing/proof", "#/marketing/reference",
  "#/clients/rules", "#/clients/tools", "#/clients/send", "#/clients/projects", "#/decisions", "#/evidence", "#/playbook", "#/settings", "#/search?q=follow%20up", "#/search?q=pricing"];
/* Pages whose content is meant to change, and why. */
const EXPECTED = { "#/marketing/people": "lead fields and filter", "#/evidence": "Leads and quotes panel", "#/clients/rules": "one-follow-up rule text", "#/search?q=follow%20up": "rule text in results", "#/home": "follow-up wording" };
const people = [{ id: "x1", name: "Plain Contact", role: "Peer", warmth: "known", stage: "conversation", lastContact: "2026-09-01", next: "Say hello", followUp: "", notes: "" }];
const state = stateWith(people, { projects: [{ id: "pr1", name: "Test Practice", price: 495, deposit: "Paid", stage: "Build", next: "Build home page" }], evidence: [{ id: "e1", what: "Asked about price", type: "lead", learned: "", change: "No", date: "2026-09-20" }] });
let a, z, b;
before(async () => { a = await serve(OLD); z = await serve(NEW); b = await browser(); });
after(async () => { await b.close(); a.server.close(); z.server.close(); });

for (const w of [390, 1280]) test(`routes at ${w}px: only intended pages change, no errors, no overflow`, async () => {
  const changed = [];
  fs.mkdirSync("tests/out", { recursive: true });
  for (const r of ROUTES) {
    const o = await open(b, a.url, { state, hash: r, viewport: { width: w, height: 900 } });
    const n = await open(b, z.url, { state, hash: r, viewport: { width: w, height: 900 } });
    const [ho, hn] = [await o.page.locator("#main").innerHTML(), await n.page.locator("#main").innerHTML()];
    const ov = await n.page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.equal(ov <= 0, true, `${r} overflows by ${ov}px at ${w}`);
    assert.deepEqual(n.errors, [], `${r} console errors`);
    const [so, sn] = [await o.page.screenshot({ fullPage: true }), await n.page.screenshot({ fullPage: true })];
    if (ho !== hn || !so.equals(sn)) { changed.push(r); fs.writeFileSync(`tests/out/${w}-${r.replace(/[^a-z0-9]+/gi, "_")}.png`, sn); }
    await o.ctx.close(); await n.ctx.close();
  }
  const unexpected = changed.filter((r) => !EXPECTED[r]);
  assert.deepEqual(unexpected, [], `unexpected visual/content change: ${unexpected.join(", ")}`);
  console.log(`# ${w}px changed: ${changed.join(", ") || "none"}`);
});
