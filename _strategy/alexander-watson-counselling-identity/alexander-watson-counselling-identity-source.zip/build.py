#!/usr/bin/env python3
"""Build the Alexander Watson Counselling — Practice Clarity & Identity guide.

Assembles src/p*.html, resolves page references, inlines the supplied logo
artwork and the font, renders an A4 PDF with Chromium, and fails on:
  - a page whose content overruns its bottom margin
  - an unresolved {{token}}
  - a hex value in the source that is not in the palette
  - a text pairing claimed in the contrast table that does not measure as stated
It also writes a word-count report for the four descriptions.
"""
import asyncio, base64, glob, json, re, sys, pathlib
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer

ROOT = pathlib.Path(__file__).parent
SRC = ROOT / 'src'
OUT = ROOT / 'out'
OUT.mkdir(exist_ok=True)

PALETTE = {
    'Ink': '#1A2119', 'Paper': '#F4F3EF', 'Recess': '#E8E7E1', 'White': '#FFFFFF',
    'Graphite': '#51564F', 'Rule': '#C8C8C0', 'Attention': '#E9E34A',
    'Mist': '#A6ABA4', 'Rule on Ink': '#3A423A',
}
# values allowed in source that are not palette values (the studio's own colours,
# shown only on the page comparing the two identities; black for one-colour print)
ALLOWED_EXTRA = {'#283A38', '#798371', '#F7F4EF', '#000000', '#777777', '#777'}

def lin(c):
    c = c / 255
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
def lum(h):
    h = h.lstrip('#'); r, g, b = [int(h[i:i+2], 16) for i in (0, 2, 4)]
    return 0.2126*lin(r) + 0.7152*lin(g) + 0.0722*lin(b)
def contrast(a, b):
    x, y = sorted([lum(a), lum(b)], reverse=True)
    return (x + 0.05) / (y + 0.05)
def rgb(h):
    h = h.lstrip('#'); return ' '.join(str(int(h[i:i+2], 16)) for i in (0, 2, 4))
def cmyk(h):
    h = h.lstrip('#'); r, g, b = [int(h[i:i+2], 16)/255 for i in (0, 2, 4)]
    k = 1 - max(r, g, b)
    if k >= 1: return '0 0 0 100'
    return ' '.join(str(round(100*v)) for v in ((1-r-k)/(1-k), (1-g-k)/(1-k), (1-b-k)/(1-k), k))

# ---------- logo artwork ----------
def art_body(name):
    s = (ROOT / name).read_text()
    s = re.sub(r'<\?xml.*?\?>', '', s, flags=re.S)
    s = re.sub(r'<!--.*?-->', '', s, flags=re.S)
    s = re.sub(r'<style.*?</style>', '', s, flags=re.S)
    body = re.search(r'<svg[^>]*>(.*)</svg>', s, flags=re.S).group(1)
    body = body.replace('class="st2"', '')
    return body.strip()

PRIMARY = art_body('alexander-watson-primary-logo.svg')
ALTERNATE = art_body('Alexander-Watson-Alternate-logo.svg')
SUBMARK = art_body('Alexander-Watson-Submark.svg')

# measured from the artwork (see page on construction): units in a 2000-wide field
CAP_NAME, CAP_SURNAME, BASE_NAME, BASE_SURNAME = 233, 144, 241, 490
DESC_CAP = 108            # 0.75 x surname cap height
fontN = ROOT / 'fonts/atkinson-hyperlegible-next-latin-wght-normal.woff2'
tt = TTFont(str(fontN))
CAP_RATIO = tt['OS/2'].sCapHeight / tt['head'].unitsPerEm
DESC_SIZE = round(DESC_CAP / CAP_RATIO, 1)

def text_width(text, wght):
    f = instancer.instantiateVariableFont(TTFont(str(fontN)), {'wght': wght})
    cmap = f.getBestCmap(); hm = f['hmtx']
    upm = f['head'].unitsPerEm
    return sum(hm[cmap[ord(c)]][0] for c in text) / upm

LOC = 'Greater Manchester and online'
def lockup_stacked(cls=''):
    h = BASE_SURNAME + CAP_SURNAME + DESC_CAP + 10
    return (f'<svg class="{cls}" viewBox="0 0 2000 {h}" role="img" aria-label="Alexander Watson, Counselling" fill="currentColor">'
            f'<g>{PRIMARY}</g>'
            f'<text x="1000" y="{BASE_SURNAME + CAP_SURNAME + DESC_CAP}" text-anchor="middle" '
            f'font-family="AHN" font-weight="500" font-size="{DESC_SIZE}">Counselling</text></svg>')

def lockup_h(cls='', loc=True):
    gap = int(1.5 * CAP_SURNAME)
    x = 1986 + gap
    w1 = text_width('Counselling', 500) * DESC_SIZE
    w2 = text_width(LOC, 400) * DESC_SIZE if loc else 0
    W = int(x + max(w1, w2) + 20)
    t2 = (f'<text x="{x}" y="{BASE_SURNAME}" font-family="AHN" font-weight="400" '
          f'font-size="{DESC_SIZE}">{LOC}</text>') if loc else ''
    y1 = BASE_NAME if loc else 250 + DESC_CAP // 2
    return (f'<svg class="{cls}" viewBox="0 0 {W} 500" role="img" aria-label="Alexander Watson, Counselling" fill="currentColor">'
            f'<g>{PRIMARY}</g>'
            f'<text x="{x}" y="{y1}" font-family="AHN" font-weight="500" font-size="{DESC_SIZE}">Counselling</text>{t2}</svg>')

TOKENS = {
    'LOGO_PRIMARY': f'<svg viewBox="0 0 2000 500" role="img" aria-label="Alexander Watson" fill="currentColor">{PRIMARY}</svg>',
    'LOGO_ALT': f'<svg viewBox="0 0 2000 500" role="img" aria-label="Alexander Watson, alternate artwork" fill="currentColor">{ALTERNATE}</svg>',
    'LOGO_SUB': f'<svg viewBox="0 0 2000 1890" role="img" aria-label="A" fill="currentColor">{SUBMARK}</svg>',
    'LOCKUP_STACKED': lockup_stacked(),
    'LOCKUP_H': lockup_h(),
    'LOCKUP_H1': lockup_h(loc=False),
    'DESC_SIZE': str(DESC_SIZE),
    'CAP_RATIO': f'{CAP_RATIO:.3f}',
}
for n, h in PALETTE.items():
    k = n.upper().replace(' ', '_')
    TOKENS[f'HEX_{k}'] = h
    TOKENS[f'RGB_{k}'] = rgb(h)
    TOKENS[f'CMYK_{k}'] = cmyk(h)

def ctoken(m):
    a, b = m.group(1), m.group(2)
    return f'{contrast(PALETTE[a], PALETTE[b]):.2f}:1'

def b64(p):
    return 'data:font/woff2;base64,' + base64.b64encode(p.read_bytes()).decode()

def assemble(font_mode):
    parts = sorted(glob.glob(str(SRC / 'p*.html')))
    html = '\n'.join(pathlib.Path(p).read_text() for p in parts)
    css = (SRC / 'style.css').read_text()
    if font_mode == 'inline':
        css = css.replace('{{FONT_NORMAL}}', b64(fontN))
        css = css.replace('{{FONT_ITALIC}}', b64(ROOT / 'fonts/atkinson-hyperlegible-next-latin-wght-italic.woff2'))
    # pages: number them, add running heads and folios
    pages = re.findall(r'<section class="page[^"]*"[^>]*>', html)
    ids = {}
    n = 0
    def number(m):
        nonlocal n
        n += 1
        tag = m.group(0)
        idm = re.search(r'data-id="([^"]+)"', tag)
        if idm: ids[idm.group(1)] = n
        part = re.search(r'data-part="([^"]*)"', tag)
        head = ''
        if part and 'nohead' not in tag:
            head = (f'<div class="rh"><span>Alexander Watson · Counselling — Practice Clarity &amp; Identity</span>'
                    f'<span>{part.group(1)}</span></div>')
        folio = '' if 'nofolio' in tag else f'<div class="folio">{n:02d}</div><div class="foot">Version 1.0 · draft for review · September 2026</div>'
        return tag + head + folio
    html = re.sub(r'<section class="page[^"]*"[^>]*>', number, html)
    total = n
    html = html.replace('{{TOTAL}}', str(total))
    html = html.replace(' — ', ' – ').replace('—', '–')
    html = re.sub(r'\{\{P:([\w-]+)\}\}', lambda m: f'{ids[m.group(1)]:02d}' if m.group(1) in ids else m.group(0), html)
    html = re.sub(r'\{\{C:([\w ]+)/([\w ]+)\}\}', ctoken, html)
    for k, v in TOKENS.items():
        html = html.replace('{{' + k + '}}', v)
    for k, v in wordcounts(html).items():
        html = html.replace('{{WC:' + k + '}}', str(v))
    doc = (f'<!doctype html><html lang="en-GB"><head><meta charset="utf-8">'
           f'<title>Alexander Watson · Counselling — Practice Clarity &amp; Identity</title>'
           f'<style>{css}</style></head><body>{html}</body></html>')
    left = re.findall(r'\{\{[^}]+\}\}', doc)
    if left:
        print('UNRESOLVED TOKENS:', sorted(set(left)))
        if '--strict' in sys.argv: sys.exit(1)
    return doc, total, ids

def check_hex(doc):
    allowed = {h.upper() for h in PALETTE.values()} | {h.upper() for h in ALLOWED_EXTRA}
    body = re.sub(r'data:font[^)"]+', '', doc)
    found = {h.upper() for h in re.findall(r'#[0-9A-Fa-f]{6}\b', body)}
    bad = found - allowed
    if bad:
        print('HEX NOT IN PALETTE:', bad); sys.exit(1)

def wordcounts(doc):
    out = {}
    for m in re.finditer(r'data-wc="(\w+)"[^>]*>(.*?)</div>', doc, flags=re.S):
        txt = re.sub(r'<[^>]+>', ' ', m.group(2))
        words = [w for w in txt.split() if re.search(r'[\w£\[]', w)]
        out[m.group(1)] = len(words)
    return out

async def render(doc_path, pdf_path):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        await pg.goto('file://' + str(doc_path))
        await pg.evaluate('document.fonts.ready')
        await pg.wait_for_timeout(400)
        over = await pg.evaluate('''() => {
          const res = [];
          document.querySelectorAll('section.page').forEach((s, i) => {
            const pb = s.getBoundingClientRect();
            const limit = pb.bottom - 16*3.7795;   // 16mm bottom margin
            let worst = 0, who = '';
            s.querySelectorAll('*').forEach(el => {
              if (el.closest('.folio,.foot')) return;
              const r = el.getBoundingClientRect();
              if (r.height === 0) return;
              if (r.bottom - limit > worst) { worst = r.bottom - limit; who = el.className || el.tagName; }
              if (r.right > pb.right - 14*3.7795 + 1 && !el.closest('.bleed')) {
                if (r.right - (pb.right - 15*3.7795) > 2) res.push([i+1, 'right', Math.round(r.right-(pb.right-15*3.7795)), el.className||el.tagName]);
              }
            });
            if (worst > 1) res.push([i+1, 'bottom', Math.round(worst), who]);
          });
          return res; }''')
        await pg.pdf(path=str(pdf_path), format='A4', print_background=True, prefer_css_page_size=True)
        await b.close()
        return over

def main():
    doc, total, ids = assemble('inline')
    check_hex(doc)
    (OUT / 'guide.html').write_text(doc)
    over = asyncio.run(render(OUT / 'guide.html', OUT / 'guide.pdf'))
    wc = wordcounts(doc)
    print('pages', total)
    print('wordcounts', wc)
    # dedupe overflow report per page
    seen = {}
    for pgno, kind, amt, who in over:
        key = (pgno, kind)
        if key not in seen or amt > seen[key][0]: seen[key] = (amt, who)
    for (pgno, kind), (amt, who) in sorted(seen.items()):
        print(f'OVERFLOW p{pgno:02d} {kind} {amt}px  {who}')
    json.dump({'pages': total, 'ids': ids, 'wc': wc, 'overflow': [list(k)+list(v) for k, v in seen.items()]},
              open(OUT / 'report.json', 'w'), indent=1)

if __name__ == '__main__':
    main()
